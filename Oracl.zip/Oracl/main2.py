# This Python file uses the following encoding: utf-8
import os, sys
import gettext
import PySimpleGUI as sg
import numpy as np
import math
from tkinter import *
import tkinter
import tkinter.messagebox as mb
import customtkinter
import tkinter.filedialog
import random
from random import choice
import time
import pygame
from pygame.locals import *
from itertools import count
import string

gettext.install('base')

def select_language(language):
    print("LANG")
    lang = gettext.translation('base', localedir='locales', languages=[language], fallback=True)
    lang.install()

#окно лабиринта
class Toplevel11Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.master = master
        #self.attributes('-zoomed', True)
        #self.wm_attributes('-type', 'splash')
        self.geometry("1x1")
        self.after(1, self.destroy)
        mozg2 = "" 
        # шрифты лабиринта
        AppFont = 'Any 16'
        AppFont2 = 'Any 12'
        AppFont3 = 'Any 58'
        AppFont4 = 'Any 50'
        AppFont5 = 'Any 18'
        AppFont7 = 'Any 28'

        # открытие файла ходов и прочей святотени
        if select_player == 1:
            sg.theme('DarkBrown5')
            ava_lab = '/home/lord/MEGAsync/books/python/Oracl/image/Ava1.1.png'
            with open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer1.txt", 'r') as f:
                file_step_1 = f.read()               
            mozg2 = int(file_step_1[0:3])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                file_intu_1 = f.read()               
            intu = int(file_intu_1[0:2])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                file_memory_1 = f.read()               
            memory = int(file_memory_1[0:2])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                file_concentration_1 = f.read()               
            concentration = int(file_concentration_1[0:2])
            print (concentration)            
        if select_player == 2:
            sg.theme('Topanga')
            ava_lab = '/home/lord/MEGAsync/books/python/Oracl/image/Ava2.1.png'
            with open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer2.txt", 'r') as f:
                file_step_2 = f.read()               
            mozg2 = int(file_step_2[0:3])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                file_intu_2 = f.read()               
            intu = int(file_intu_2[0:2])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                file_memory_2 = f.read()               
            memory = int(file_memory_2[0:2])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                file_concentration_2 = f.read()               
            concentration = int(file_concentration_2[0:2])
        if select_player == 3:
            sg.theme('DarkGray3')
            ava_lab = '/home/lord/MEGAsync/books/python/Oracl/image/Ava3.1.png'
            with open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer3.txt", 'r') as f:
                file_step_3 = f.read()               
            mozg2 = int(file_step_3[0:3])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
                file_intu_3 = f.read()               
            intu = int(file_intu_3[0:2])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
                file_memory_3 = f.read()               
            memory = int(file_memory_3[0:2])
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
                file_concentration_3 = f.read()               
            concentration = int(file_concentration_3[0:2])
        
        # загрузочное окно              # не удалять
        for i in range(mozg2):   
            if not sg.one_line_progress_meter('Загрузка лабиринта', i + 1, mozg2, 'Анализ данных ', i*1512):
                break
            
        # размер, количество клеток, позиция активных клеток
        _VARS = {'cellCount': 64, 'gridSize': 682, 'window': 1200,  #'canvas': False,  'cellMAP': False,
                 'playerPos': [10, 10], 'exit': [28, 31],
                 "bonus":[9, 8], "bonus2":[18, 12], "bonus3":[17, 18], "bonus4":[10, 35], "bonus5":[44, 13], "bonus6":[54, 31], "bonus7":[24, 37],
                 "bonus8":[27, 42], "bonus9":[36, 15], "bonus10":[7, 58], "bonus11":[28, 50],
                 "secret passage1":[1, 5], "secret passage2":[9, 34], "secret passage3":[10, 37], "secret passage4":[25, 39], "secret passage5":[28, 30],
                 "secret passage6":[32, 12], "secret passage7":[50, 55], "secret passage8":[55, 22], "secret passage9":[61, 52], "secret passage10":[61, 50],
                 "secret passage11":[61, 48], "secret passage12":[61, 46], "secret passage13":[61, 44], "secret passage14":[61, 42],
                 "secret passage15":[61, 40], "secret passage16":[61, 38], "secret passage17":[61, 36], "secret passage18":[61, 34],
                 "secret passage19":[61, 32], "secret passage20":[61, 30], "secret passage21":[61, 28], "secret passage22":[61, 26],
                 "secret passage23":[61, 24], "secret passage24":[36, 10]}
        cellSize = _VARS['gridSize']/_VARS['cellCount']
        
        # шаг\ход
        global Step, Step_intu, Step_memory, Step_concentration
        Step_intu = ""
        Step = mozg2
        Step_intu = intu
        Step_memory = memory 
        Step_concentration = concentration 
        
        # массив лабиринта
        cellMAP = np.array([[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                            [1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                            [1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
                            [1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1],
                            [1, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 0, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 0, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 2, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 2, 2, 2, 2, 2, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 1, 1, 1, 2, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 1, 2, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 1, 2, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 2, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 1, 2, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1],
                            [1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1],
                            [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 2, 1, 2, 2, 2, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1],
                            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 2, 1, 1, 1, 2, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 2, 2, 2, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 0, 1, 2, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1],
                            [1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 1, 2, 1, 0, 1, 2, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 2, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 2, 1, 0, 1, 2, 2, 2, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 0, 1, 2, 1, 0, 1, 1, 1, 2, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 0, 1, 2, 1, 0, 0, 0, 1, 2, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1],                            
                            [1, 0, 1, 2, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 0, 1, 2, 1, 0, 1, 0, 1, 8, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 0, 1, 2, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 0, 1, 2, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 2, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 2, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 2, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 2, 1, 0, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 2, 1, 0, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 1, 1, 0, 0, 1],
                            [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 2, 1, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 2, 0, 0, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 2, 2, 2, 2, 2, 1, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 2, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1],
                            [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 2, 2, 2, 2, 2, 1, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 2, 1, 0, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 2, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1],
                            [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 1, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 2, 1, 0, 0, 1, 0, 0, 1, 1],
                            [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2, 2, 1, 0, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 2, 1, 0, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
                            [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1],
                            [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1],
                            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1],
                            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],                            
                            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]])

        # внешний вид сетки 
        def drawGrid():
            cells = _VARS['cellCount']
            # размер , толщина линии и цвет
            _VARS['canvas'].TKCanvas.create_rectangle(1, 1, _VARS['gridSize'], _VARS['gridSize'], outline='#632680', width=1)
            for x in range(cells):
                # по вертикали
                _VARS['canvas'].TKCanvas.create_line(
                    ((cellSize * x), 0), ((cellSize * x), _VARS['gridSize']),
                    fill='#632680', width=1)
                # по горизонтали
                _VARS['canvas'].TKCanvas.create_line(
                    (0, (cellSize * x)), (_VARS['gridSize'], (cellSize * x)),
                    fill='#632680', width=1)
                
        # вид темной области      
        def drawMist(x, y, color='#000000'):
            _VARS['canvas'].TKCanvas.create_rectangle(x, y, x + cellSize, y + cellSize, outline='', fill=color, width=1)
                
        # вид  маршрута      
        def drawWall(x, y, color='#4f90a5'):
            _VARS['canvas'].TKCanvas.create_rectangle(x, y, x + cellSize, y + cellSize, outline='', fill=color, width=1)
            
        # вид стен
        def drawCell(x, y, color= "#001E1E"):
            _VARS['canvas'].TKCanvas.create_rectangle(x, y, x + cellSize, y + cellSize, outline='', fill=color, width=1)
                                                     
        # функция массива numpy в качестве карты для стен 
        def placeCells():
            for row in range(cellMAP.shape[0]):
                for column in range(cellMAP.shape[1]):
                    
                    if(cellMAP[column][row] == 1):
                        drawCell((cellSize*row), (cellSize*column))
                    #if(cellMAP[column][row] == 2):    # не удалять
                        #drawWall((cellSize*row), (cellSize*column))    # не удалять
                        
        # нажатие кнопки
        def checkEvents(event):
            move = ''
            if len(event) == 1:           
                if ord(event) == 63232:  # вверх 0.25
                    move = 'Up'  
                elif ord(event) == 63233:  # вниз 0.50
                    move = 'Down'                  
                elif ord(event) == 63234:  # лево 0.75
                    move = 'Left' 
                elif ord(event) == 63235:  # право 1.0
                    move = 'Right'
                    
            if event == "⇧":
                move = 'Up'
                self.master.play13()
            if event == "⇩":
                move = 'Down'
                self.master.play13()
            if event == "⇦":
                move = 'Left'
                self.master.play13()
            if event == "⇨":
                move = 'Right'
                self.master.play13()
                
            # фильтр нажатия кнопки
            else:
                if event.startswith('Up'):
                    move = 'Up'                    
                elif event.startswith('Down'):
                    move = 'Down'                    
                elif event.startswith('Left'):
                    move = 'Left'                   
                elif event.startswith('Right'):
                    move = 'Right'
            return move
                  
        # вид и положение инфо  _VARS['canvas'].TKCanvas.create__image(700,700, anchor=CENTER, image = wall)  [sg.Image("GmS5.png")]]
        zero_col = [[sg.Text(_('Вперед!'), pad=((2,0),(5,2)), key='-steps-', font=AppFont5, size=(15, 1))],
                    [sg.Text(_('Интуиция = ') + str(Step_intu), pad=((2,0),(5,2)), key='-intu-', font=AppFont5, size=(18, 1))],
                    [sg.Text(_('Память = ') + str(Step_memory), pad=((2,0),(5,2)), key='-memory-', font=AppFont5, size=(18, 1))],
                    [sg.Text(_('Концентрация = ') + str(Step_concentration), pad=((2,0),(5,2)), key='-concentration-', font=AppFont5, size=(20, 1))],
                    [sg.Text(_('Инфо 1'), pad=((2,0),(5,2)), key='-exit-', font=AppFont2, size=(20, 1))],
                    [sg.Text(_('Инфо 2'), pad=((2,0),(5,2)), key='-exit-', font=AppFont2, size=(20, 1))],
                    [sg.vbottom(sg.Exit("EXIT",  pad=((28,30), (280, 2)), size=(8, 2), font=AppFont))]]

        # вид и положение поля
        left_col = [[sg.Canvas(size=(_VARS['gridSize'], _VARS['gridSize']), pad=((8,0),(0,0)), background_color='#97602C', key='canvas')]]

        # положение кнопок  
        right_col = [[sg.Image(ava_lab, expand_x=True, expand_y=True )],
                    [sg.Button("⇧", pad=((128,0),(200,2)), size=(3, 2), font=AppFont)],
                    [sg.Button("⇦", pad=((55, 2),(2, 0)), size=(3, 2), font=AppFont), sg.Button("S", pad=((0, 0),(0, 0)), size=(3, 2), font=AppFont),\
                     sg.Button("⇨", pad=((2, 5),(0, 0)), size=(3, 2), font=AppFont)],
                    [sg.Button("⇩", pad=((128,0), (2, 15)), size=(3, 2), font=AppFont)],]
      
        # вид окна
        col1= sg.Column(zero_col)
        col2 = sg.Column(left_col)
        col3 = sg.Column(right_col)
        
        layout = [[col1, col2, col3]]

        _VARS['window'] = sg.Window(_('Labirint 1'), layout, no_titlebar=False, resizable=True, finalize=True,  auto_size_text=True, auto_size_buttons=True, 
                                    return_keyboard_events=True)#.Finalize()
        _VARS['canvas'] = _VARS['window']['canvas']
        drawGrid()
        _VARS['window'].Maximize()

       # col1.expand(True, True)
       # col2.expand(True, True)
        col3.expand(True, True)

        # клетка игрока
        drawCell(_VARS['playerPos'][0], _VARS['playerPos'][1], '#FFAD00')
        
        # клетка выхода
        drawCell(_VARS['exit'][0]*cellSize, _VARS['exit'][1]*cellSize, '#AAFF00')

        # клетка телепорта
        drawCell(_VARS["bonus"][0]*cellSize, _VARS["bonus"][1]*cellSize, '')
        drawCell(_VARS["bonus2"][0]*cellSize, _VARS["bonus2"][1]*cellSize, '#FF3C00')
        drawCell(_VARS["bonus3"][0]*cellSize, _VARS["bonus3"][1]*cellSize, '#FF006F')
        drawCell(_VARS["bonus4"][0]*cellSize, _VARS["bonus4"][1]*cellSize, '#1DF024')
        drawCell(_VARS["bonus5"][0]*cellSize, _VARS["bonus5"][1]*cellSize, '#166C52')
        drawCell(_VARS["bonus6"][0]*cellSize, _VARS["bonus6"][1]*cellSize, '#3F3A7F')
        drawCell(_VARS["bonus7"][0]*cellSize, _VARS["bonus7"][1]*cellSize, '#0056FF')
        drawCell(_VARS["bonus8"][0]*cellSize, _VARS["bonus8"][1]*cellSize, '')
        drawCell(_VARS["bonus9"][0]*cellSize, _VARS["bonus9"][1]*cellSize, '')
        if select_player == 2:
            drawCell(_VARS["bonus10"][0]*cellSize, _VARS["bonus10"][1]*cellSize, '')
        drawCell(_VARS["bonus11"][0]*cellSize, _VARS["bonus11"][1]*cellSize, '#FF3C00')            
        
        # клетка тайного прохода
        drawCell(_VARS["secret passage1"][0]*cellSize, _VARS["secret passage1"][1]*cellSize, '#001E1E')   
        drawCell(_VARS["secret passage2"][0]*cellSize, _VARS["secret passage2"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage3"][0]*cellSize, _VARS["secret passage3"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage4"][0]*cellSize, _VARS["secret passage4"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage5"][0]*cellSize, _VARS["secret passage5"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage6"][0]*cellSize, _VARS["secret passage6"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage7"][0]*cellSize, _VARS["secret passage7"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage8"][0]*cellSize, _VARS["secret passage8"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage9"][0]*cellSize, _VARS["secret passage9"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage10"][0]*cellSize, _VARS["secret passage10"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage11"][0]*cellSize, _VARS["secret passage11"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage12"][0]*cellSize, _VARS["secret passage12"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage13"][0]*cellSize, _VARS["secret passage13"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage14"][0]*cellSize, _VARS["secret passage14"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage15"][0]*cellSize, _VARS["secret passage15"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage16"][0]*cellSize, _VARS["secret passage16"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage17"][0]*cellSize, _VARS["secret passage17"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage18"][0]*cellSize, _VARS["secret passage18"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage19"][0]*cellSize, _VARS["secret passage19"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage20"][0]*cellSize, _VARS["secret passage20"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage21"][0]*cellSize, _VARS["secret passage21"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage22"][0]*cellSize, _VARS["secret passage22"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage23"][0]*cellSize, _VARS["secret passage23"][1]*cellSize, '#001E1E')
        drawCell(_VARS["secret passage24"][0]*cellSize, _VARS["secret passage24"][1]*cellSize, '#001E1E')
        
        # прочитать массив numpy в качестве карты для сетки
        placeCells()

        # петля событий
        while True:
            # обратный счет ходов
            if select_player == 1 or select_player == 3:
                Step -= 1
            else:
                Step -= 2                
            if Step <= 0:
                _VARS['window'].close()
                if sg.Window(_("Поражение"), [[sg.Text(_("Безславный конец!"), pad=((80,25),20), font=AppFont3, size=(18, 1))],
                          [sg.Button(_("Понятно..."), pad=((50,50),20), size=(20, 1), font=AppFont,)]]).read(close=True)[0] == _("Понятно..."):
                    break
                
            if select_player == 1:    
                Step_intu -= 0.01
                Step_memory -= 0.01
                Step_concentration -= 0.02
            if select_player == 2:    
                Step_intu -= 0
                Step_memory -= 0.01
                Step_concentration -= 0.01
            if select_player == 3:    
                Step_intu -= 0.02
                Step_memory -= 0.02
                Step_concentration -= 0.02
                
            # отображение значений в окне
            event, values = _VARS['window'].read()
            
            # функция кнопки закрытия окна
            if event in (None, _("EXIT")):
                break

            # функция перемещения и указание стены как препятствия
            xPos = int(math.ceil(_VARS['playerPos'][0]/cellSize))
            yPos = int(math.ceil(_VARS['playerPos'][1]/cellSize))    

            if checkEvents(event) == 'Up':
                if int(_VARS['playerPos'][1] - cellSize) >= 0:
                    if cellMAP[yPos-1][xPos] != 1:
                        _VARS['playerPos'][1] = _VARS['playerPos'][1] - cellSize
                        
            elif checkEvents(event) == 'Down':
                if int(_VARS['playerPos'][1] + cellSize) < _VARS['gridSize']-1:
                    if cellMAP[yPos+1][xPos] != 1:
                        _VARS['playerPos'][1] = _VARS['playerPos'][1] + cellSize
                        
            elif checkEvents(event) == 'Left':
                if int(_VARS['playerPos'][0] - cellSize) >= 0:
                    if cellMAP[yPos][xPos-1] != 1:
                        _VARS['playerPos'][0] = _VARS['playerPos'][0] - cellSize
                        
            elif checkEvents(event) == 'Right':
                if int(_VARS['playerPos'][0] + cellSize) < _VARS['gridSize']-1:
                    if cellMAP[yPos][xPos+1] != 1:
                        _VARS['playerPos'][0] = _VARS['playerPos'][0] + cellSize

            # очистка холста, отрисовка сетки и ячейки
            _VARS['canvas'].TKCanvas.delete("all")
            drawGrid()
            drawCell(_VARS['exit'][0]*cellSize, _VARS['exit'][1]*cellSize, '#AAFF00')
            drawCell(_VARS['playerPos'][0], _VARS['playerPos'][1], '#FFAD00')
            drawCell(_VARS["bonus"][0]*cellSize, _VARS["bonus"][1]*cellSize, '')
            drawCell(_VARS["bonus2"][0]*cellSize, _VARS["bonus2"][1]*cellSize, '#FF3C00')
            drawCell(_VARS["bonus3"][0]*cellSize, _VARS["bonus3"][1]*cellSize, '#FF006F')
            drawCell(_VARS["bonus4"][0]*cellSize, _VARS["bonus4"][1]*cellSize, '#1DF024')
            drawCell(_VARS["bonus5"][0]*cellSize, _VARS["bonus5"][1]*cellSize, '#166C52')
            drawCell(_VARS["bonus6"][0]*cellSize, _VARS["bonus6"][1]*cellSize, '#3F3A7F')
            drawCell(_VARS["bonus7"][0]*cellSize, _VARS["bonus7"][1]*cellSize, '#0056FF')
            drawCell(_VARS["bonus8"][0]*cellSize, _VARS["bonus8"][1]*cellSize, '')
            drawCell(_VARS["bonus9"][0]*cellSize, _VARS["bonus9"][1]*cellSize, '')
            if select_player == 2:
                drawCell(_VARS["bonus10"][0]*cellSize, _VARS["bonus10"][1]*cellSize, '')
            drawCell(_VARS["bonus11"][0]*cellSize, _VARS["bonus11"][1]*cellSize, '#FF3C00')
            
            drawCell(_VARS["secret passage1"][0]*cellSize, _VARS["secret passage1"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage2"][0]*cellSize, _VARS["secret passage2"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage3"][0]*cellSize, _VARS["secret passage3"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage4"][0]*cellSize, _VARS["secret passage4"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage5"][0]*cellSize, _VARS["secret passage5"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage6"][0]*cellSize, _VARS["secret passage6"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage7"][0]*cellSize, _VARS["secret passage7"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage8"][0]*cellSize, _VARS["secret passage8"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage9"][0]*cellSize, _VARS["secret passage9"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage10"][0]*cellSize, _VARS["secret passage10"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage11"][0]*cellSize, _VARS["secret passage11"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage12"][0]*cellSize, _VARS["secret passage12"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage13"][0]*cellSize, _VARS["secret passage13"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage14"][0]*cellSize, _VARS["secret passage14"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage15"][0]*cellSize, _VARS["secret passage15"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage16"][0]*cellSize, _VARS["secret passage16"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage17"][0]*cellSize, _VARS["secret passage17"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage18"][0]*cellSize, _VARS["secret passage18"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage19"][0]*cellSize, _VARS["secret passage19"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage20"][0]*cellSize, _VARS["secret passage20"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage21"][0]*cellSize, _VARS["secret passage21"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage22"][0]*cellSize, _VARS["secret passage22"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage23"][0]*cellSize, _VARS["secret passage23"][1]*cellSize, '#001E1E')
            drawCell(_VARS["secret passage24"][0]*cellSize, _VARS["secret passage24"][1]*cellSize, '#001E1E')
            
            placeCells()

            # функция реакции на клетки
            xPos = int(math.ceil(_VARS['playerPos'][0]/cellSize))
            yPos = int(math.ceil(_VARS['playerPos'][1]/cellSize))
            
            if [xPos, yPos] == _VARS['bonus']:
                drawCell(_VARS["bonus"][0]*cellSize, _VARS["bonus"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна '), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] + 4*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] - 8*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus2']:
                drawCell(_VARS["bonus2"][0]*cellSize, _VARS["bonus2"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] + 50*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] + 41*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus3']:
                drawCell(_VARS["bonus3"][0]*cellSize, _VARS["bonus3"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] - 13*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] + 26*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus4']:
                drawCell(_VARS["bonus4"][0]*cellSize, _VARS["bonus4"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] + 25*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] - 1*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus5']:
                drawCell(_VARS["bonus5"][0]*cellSize, _VARS["bonus5"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] - 4*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] + 12*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus6']:
                drawCell(_VARS["bonus6"][0]*cellSize, _VARS["bonus6"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] + 8*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] - 32*cellSize
                Step += 20
                self.master.play14()
                
            if [xPos, yPos] == _VARS['bonus7']:
                drawCell(_VARS["bonus7"][0]*cellSize, _VARS["bonus7"][1]*cellSize, '#FFAD00')
                sg.popup(_('Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] - 10*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] - 2*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus8']:
                drawCell(_VARS["bonus8"][0]*cellSize, _VARS["bonus8"][1]*cellSize, '#FFAD00')
                sg.popup(_('Ловушка! Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] + 16*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] - 14*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS['bonus9']:
                drawCell(_VARS["bonus9"][0]*cellSize, _VARS["bonus9"][1]*cellSize, '#FF006F')
                sg.popup(_('Ловушка! Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] + 18*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] - 0*cellSize
                Step += 20
                self.master.play14()

            if select_player == 2:
                if [xPos, yPos] == _VARS['bonus10']:
                    drawCell(_VARS["bonus10"][0]*cellSize, _VARS["bonus10"][1]*cellSize, '#FF006F')
                    sg.popup(_('Как это возможно! Телепортация неизбежна'), font=AppFont7, no_titlebar=False, keep_on_top=True)
                    _VARS['playerPos'][1] = _VARS['playerPos'][1] -3*cellSize
                    _VARS['playerPos'][0] = _VARS['playerPos'][0] - 0*cellSize
                    Step += 20
                    self.master.play14()

            if [xPos, yPos] == _VARS['bonus11']:
                drawCell(_VARS["bonus11"][0]*cellSize, _VARS["bonus11"][1]*cellSize, '#FF006F')
                sg.popup(_('Ловушка! Телепортация неизбежна'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                _VARS['playerPos'][1] = _VARS['playerPos'][1] - 33*cellSize
                _VARS['playerPos'][0] = _VARS['playerPos'][0] + 10*cellSize
                Step += 20
                self.master.play14()

            if [xPos, yPos] == _VARS["secret passage1"]:
                drawCell(_VARS["secret passage1"][0]*cellSize, _VARS["secret passage1"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage2"]:
                drawCell(_VARS["secret passage2"][0]*cellSize, _VARS["secret passage2"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage3"]:
                drawCell(_VARS["secret passage3"][0]*cellSize, _VARS["secret passage3"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage4"]:
                drawCell(_VARS["secret passage4"][0]*cellSize, _VARS["secret passage4"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage5"]:
                drawCell(_VARS["secret passage5"][0]*cellSize, _VARS["secret passage5"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage6"]:
                drawCell(_VARS["secret passage6"][0]*cellSize, _VARS["secret passage6"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage7"]:
                drawCell(_VARS["secret passage7"][0]*cellSize, _VARS["secret passage7"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage8"]:
                drawCell(_VARS["secret passage8"][0]*cellSize, _VARS["secret passage8"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage9"]:
                drawCell(_VARS["secret passage9"][0]*cellSize, _VARS["secret passage9"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage10"]:
                drawCell(_VARS["secret passage10"][0]*cellSize, _VARS["secret passage10"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage11"]:
                drawCell(_VARS["secret passage11"][0]*cellSize, _VARS["secret passage11"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage12"]:
                drawCell(_VARS["secret passage12"][0]*cellSize, _VARS["secret passage12"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage13"]:
                drawCell(_VARS["secret passage13"][0]*cellSize, _VARS["secret passage13"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage14"]:
                drawCell(_VARS["secret passage14"][0]*cellSize, _VARS["secret passage14"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage15"]:
                drawCell(_VARS["secret passage15"][0]*cellSize, _VARS["secret passage15"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage16"]:
                drawCell(_VARS["secret passage16"][0]*cellSize, _VARS["secret passage16"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage17"]:
                drawCell(_VARS["secret passage17"][0]*cellSize, _VARS["secret passage17"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage18"]:
                drawCell(_VARS["secret passage18"][0]*cellSize, _VARS["secret passage18"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage19"]:
                drawCell(_VARS["secret passage19"][0]*cellSize, _VARS["secret passage19"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage20"]:
                drawCell(_VARS["secret passage20"][0]*cellSize, _VARS["secret passage20"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage21"]:
                drawCell(_VARS["secret passage21"][0]*cellSize, _VARS["secret passage21"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage22"]:
                drawCell(_VARS["secret passage22"][0]*cellSize, _VARS["secret passage22"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage23"]:
                drawCell(_VARS["secret passage23"][0]*cellSize, _VARS["secret passage23"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS["secret passage24"]:
                drawCell(_VARS["secret passage24"][0]*cellSize, _VARS["secret passage24"][1]*cellSize, '#FFAD00')
                sg.popup(_('Секретный проход!'), font=AppFont4, no_titlebar=False, keep_on_top=True)
                Step -= 10
                self.master.play15()

            if [xPos, yPos] == _VARS['exit']:
                
                _VARS['window']['-exit-'].update(_('Победа!'))
                _VARS['window'].close()
                self.master.open_toplevel16()
                break

            else:
                _VARS['window']['-steps-'].update(_('Ходов ') + str(Step))
                _VARS['window']['-intu-'].update(_('Интуиция = ') + str('%.5s' % Step_intu))
                _VARS['window']['-memory-'].update(_('Память = ') + str('%.5s' % Step_memory))
                _VARS['window']['-concentration-'].update(_('Концентрация = ') + str('%.5s' % Step_concentration))

                # отнимание очков у игроков перезапись в файл
                if select_player == 1:

                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                        file_stat_player_1_game_1 = f.read()
                    stat_player_1_game_1 = [0]    
                    stat_player_1_game_1[0] = float(file_stat_player_1_game_1)
                    stat_player_1_game_1[0] -= 0.01 # штраф за ход
                    list_stat_player_1_game_1 = str(stat_player_1_game_1[0])
                    file_stat_player_1_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'w')    
                    for element in list_stat_player_1_game_1:
                         file_stat_player_1_game_1.write(element)
                    file_stat_player_1_game_1.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                        file_stat_player_1_game_1 = f.read()
                    self.master.logo_label_2_player_1.configure(text=_("Интуиция = ") + str(file_stat_player_1_game_1[0:4]) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                        file_stat_player_1_game_2 = f.read()               
                    stat_player_1_game_2 = [0]    
                    stat_player_1_game_2[0] = float(file_stat_player_1_game_2)          
                    stat_player_1_game_2[0] -= 0.01 # штраф за ход              
                    list_stat_player_1_game_2 = str(stat_player_1_game_2[0])
                    file_stat_player_1_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'w')            
                    for element in list_stat_player_1_game_2:
                         file_stat_player_1_game_2.write(element)
                    file_stat_player_1_game_2.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                        file_stat_player_1_game_2 = f.read()
                    self.master.logo_label_3_player_1.configure(text=_("Память = ") + str('%.4s' % file_stat_player_1_game_2) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                        file_stat_player_1_game_3 = f.read()                    
                    stat_player_1_game_3 = [0]    
                    stat_player_1_game_3[0] = float(file_stat_player_1_game_3)
                    stat_player_1_game_3[0] -= 0.02 # штраф за ход              
                    list_stat_player_1_game_3 = str(stat_player_1_game_3[0])
                    file_stat_player_1_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'w')         
                    for element in list_stat_player_1_game_3:
                         file_stat_player_1_game_3.write(element)
                    file_stat_player_1_game_3.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                        file_stat_player_1_game_3 = f.read()
                    self.master.logo_label_4_player_1.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_1_game_3) + "%")

                if select_player == 2:
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                        file_stat_player_2_game_1 = f.read()   
                    stat_player_2_game_1 = [0]    
                    stat_player_2_game_1[0] = float(file_stat_player_2_game_1)             
                    stat_player_2_game_1[0] -= 0.00 # штраф за ход                
                    list_stat_player_2_game_1 = str(stat_player_2_game_1[0])
                    file_stat_player_2_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'w')                
                    for element in list_stat_player_2_game_1:
                         file_stat_player_2_game_1.write(element)
                    file_stat_player_2_game_1.close()                 
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                        file_stat_player_2_game_1 = f.read()
                    self.master.logo_label_2_player_2.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_2_game_1) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                        file_stat_player_2_game_2 = f.read()                 
                    stat_player_2_game_2 = [0]    
                    stat_player_2_game_2[0] = float(file_stat_player_2_game_2)               
                    stat_player_2_game_2[0] -= 0.01 # штраф за ход                
                    list_stat_player_2_game_2 = str(stat_player_2_game_2[0])
                    file_stat_player_2_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'w')             
                    for element in list_stat_player_2_game_2:
                         file_stat_player_2_game_2.write(element)
                    file_stat_player_2_game_2.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                        file_stat_player_2_game_2 = f.read()
                    self.master.logo_label_3_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_2) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                        file_stat_player_2_game_3 = f.read()                       
                    stat_player_2_game_3 = [0]    
                    stat_player_2_game_3[0] = float(file_stat_player_2_game_3)                
                    stat_player_2_game_3[0] -= 0.01 # штраф за ход              
                    list_stat_player_2_game_3 = str(stat_player_2_game_3[0])
                    file_stat_player_2_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'w')              
                    for element in list_stat_player_2_game_3:
                         file_stat_player_2_game_3.write(element)
                    file_stat_player_2_game_3.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                        file_stat_player_2_game_3 = f.read()
                    self.master.logo_label_4_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_3) + "%")

                if select_player == 3:
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
                        file_stat_player_3_game_1 = f.read()                    
                    stat_player_3_game_1 = [0]    
                    stat_player_3_game_1[0] = float(file_stat_player_3_game_1)                
                    stat_player_3_game_1[0] -= 0.02 # штраф за ход                
                    list_stat_player_3_game_1 = str(stat_player_3_game_1[0])
                    file_stat_player_3_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'w')                  
                    for element in list_stat_player_3_game_1:
                         file_stat_player_3_game_1.write(element)
                    file_stat_player_3_game_1.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
                        file_stat_player_3_game_1 = f.read()
                    self.master.logo_label_2_player_3.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_3_game_1) + "%")                 
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
                        file_stat_player_3_game_2 = f.read()                       
                    stat_player_3_game_2 = [0]    
                    stat_player_3_game_2[0] = float(file_stat_player_3_game_2)                 
                    stat_player_3_game_2[0] -= 0.02 # штраф за ход                  
                    list_stat_player_3_game_2 = str(stat_player_3_game_2[0])
                    file_stat_player_3_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'w')                
                    for element in list_stat_player_3_game_2:
                         file_stat_player_3_game_2.write(element)
                    file_stat_player_3_game_2.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
                        file_stat_player_3_game_2 = f.read()
                    self.master.logo_label_3_player_3.configure(text=_("Память = ") + str('%.4s' % file_stat_player_3_game_2) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
                        file_stat_player_3_game_3 = f.read()                  
                    stat_player_3_game_3 = [0]    
                    stat_player_3_game_3[0] = float(file_stat_player_3_game_3)                
                    stat_player_3_game_3[0] -= 0.02 # штраф за ход               
                    list_stat_player_3_game_3 = str(stat_player_3_game_3[0])
                    file_stat_player_3_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'w')               
                    for element in list_stat_player_3_game_3:
                         file_stat_player_3_game_3.write(element)
                    file_stat_player_3_game_3.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
                        file_stat_player_3_game_3 = f.read()
                    self.master.logo_label_4_player_3.configure(text=_("Память = ") + str('%.4s' % file_stat_player_3_game_3) + "%")

                    # штрафы от игрока 3 по отношению к игрокам 1 и 2
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                        file_stat_player_1_game_1 = f.read()                  
                    stat_player_1_game_1 = [0]    
                    stat_player_1_game_1[0] = float(file_stat_player_1_game_1)               
                    stat_player_1_game_1[0] -= 0.01 # штраф за ход                  
                    list_stat_player_1_game_1 = str(stat_player_1_game_1[0])
                    file_stat_player_1_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'w')                 
                    for element in list_stat_player_1_game_1:
                         file_stat_player_1_game_1.write(element)
                    file_stat_player_1_game_1.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                        file_stat_player_1_game_1 = f.read()
                    self.master.logo_label_2_player_1.configure(text=_("Интуиция = ") + str(file_stat_player_1_game_1[0:4]) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                        file_stat_player_1_game_2 = f.read()                        
                    stat_player_1_game_2 = [0]    
                    stat_player_1_game_2[0] = float(file_stat_player_1_game_2)                 
                    stat_player_1_game_2[0] -= 0.01 # штраф за ход                  
                    list_stat_player_1_game_2 = str(stat_player_1_game_2[0])
                    file_stat_player_1_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'w')                  
                    for element in list_stat_player_1_game_2:
                         file_stat_player_1_game_2.write(element)
                    file_stat_player_1_game_2.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                        file_stat_player_1_game_2 = f.read()
                    self.master.logo_label_3_player_1.configure(text=_("Память = ") + str('%.4s' % file_stat_player_1_game_2) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                        file_stat_player_1_game_3 = f.read()                      
                    stat_player_1_game_3 = [0]    
                    stat_player_1_game_3[0] = float(file_stat_player_1_game_3)                
                    stat_player_1_game_3[0] -= 0.01 # штраф за ход             
                    list_stat_player_1_game_3 = str(stat_player_1_game_3[0])
                    file_stat_player_1_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'w')            
                    for element in list_stat_player_1_game_3:
                         file_stat_player_1_game_3.write(element)
                    file_stat_player_1_game_3.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                        file_stat_player_1_game_3 = f.read()
                    self.master.logo_label_4_player_1.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_1_game_3) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                        file_stat_player_2_game_1 = f.read()                    
                    stat_player_2_game_1 = [0]    
                    stat_player_2_game_1[0] = float(file_stat_player_2_game_1)                
                    stat_player_2_game_1[0] -= 0.01 # штраф за ход                
                    list_stat_player_2_game_1 = str(stat_player_2_game_1[0])
                    file_stat_player_2_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'w')               
                    for element in list_stat_player_2_game_1:
                         file_stat_player_2_game_1.write(element)
                    file_stat_player_2_game_1.close()               
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                        file_stat_player_2_game_1 = f.read()
                    self.master.logo_label_2_player_2.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_2_game_1) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                        file_stat_player_2_game_2 = f.read()                  
                    stat_player_2_game_2 = [0]    
                    stat_player_2_game_2[0] = float(file_stat_player_2_game_2)              
                    stat_player_2_game_2[0] -= 0.01 # штраф за ход               
                    list_stat_player_2_game_2 = str(stat_player_2_game_2[0])
                    file_stat_player_2_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'w')                  
                    for element in list_stat_player_2_game_2:
                         file_stat_player_2_game_2.write(element)
                    file_stat_player_2_game_2.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                        file_stat_player_2_game_2 = f.read()
                    self.master.logo_label_3_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_2) + "%")
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                        file_stat_player_2_game_3 = f.read()                     
                    stat_player_2_game_3 = [0]    
                    stat_player_2_game_3[0] = float(file_stat_player_2_game_3)                  
                    stat_player_2_game_3[0] -= 0.01 # штраф за ход                  
                    list_stat_player_2_game_3 = str(stat_player_2_game_3[0])
                    file_stat_player_2_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'w')                   
                    for element in list_stat_player_2_game_3:
                         file_stat_player_2_game_3.write(element)
                    file_stat_player_2_game_3.close()
                    with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                        file_stat_player_2_game_3 = f.read()
                    self.master.logo_label_4_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_3) + "%")

        _VARS['window'].close()


# окно концентрации
class Toplevel12Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.master = master
        self.title(_("Концентрация"))
        self.geometry("1100x680")
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        #self.after(2700000, self.destroy)
        self.grid_columnconfigure((0, 1, 2), weight=1)
        global shullte
        shullte = [1]    
        self.Field()
        self.field2()
        self.start_shullte()
        self.Create_controllist()
        print("List for % shullte " + str(a[0]))
        
        # поле игры
    def Field(self):
        self.sidebar_frame1 = customtkinter.CTkFrame(self, corner_radius=5, border_width=2, border_color="#454545")
        self.sidebar_frame1.grid(row=2, rowspan=7, column=3, padx=(80, 20), pady = (12, 15), sticky="nswe")
        self.sidebar_frame1.grid_rowconfigure((1,2,3,4,5,6,7,8,9,10), weight=0)
        self.sidebar_frame1.grid_columnconfigure((1,2,3,4,5,6,7,8,9,10), weight=0)

    def field2(self):
        # прогрессбар хедера 1
        self.progressbar_20 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_20.grid(row=0, column=0, columnspan=8, padx=(20, 20), pady=(5, 0), sticky="sew")
        self.progressbar_20.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_20.start()

        # название
        self.logo_field = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=22), text="Концентрация")
        self.logo_field.grid(row=1, column=0, columnspan=8, padx=(2, 2), pady=(0, 5), sticky="new")
        self.logo_field.configure(font=customtkinter.CTkFont(size=28), text_color="#ffffff")

        # прогрессбар хедера 2
        self.progressbar_20 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_20.grid(row=1, column=0, columnspan=8, padx=(20, 20), pady=(5, 2), sticky="sew")
        self.progressbar_20.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_20.start()
                
        # кнопка отмены
        self.button2 = customtkinter.CTkButton(self, fg_color="#3a689e", font=customtkinter.CTkFont(size=25), text_color_disabled="#383a3d",
                                                         text=_("Отменить"), border_width=2, width=150, height=120, command = self.cancel_number)
        self.button2.grid(row=5, rowspan = 1, column=0, columnspan = 1, padx=(50, 5), pady=(15, 0), sticky="ws")
        
        # кнопка рестарта
        self.button1 = customtkinter.CTkButton(self, fg_color="#3a689e", font=customtkinter.CTkFont(size=25), text_color_disabled="#383a3d",
                                                         text=_("Сброс"), border_width=2, width=150, height=120, command = self.Restart)
        self.button1.grid(row=5, rowspan = 1, column=1, columnspan = 1, padx=(5, 5), pady=(15, 0), sticky="ws")

        # кнопка завершения
        self.button3 = customtkinter.CTkButton(self, fg_color="#3a689e", font=customtkinter.CTkFont(size=25), text_color_disabled="#383a3d",
                                                         text=_("Закрыть"), border_width=2, width=150, height=120,
                                               command = self.sullet_exit)
        self.button3.grid(row=5, rowspan = 1, column=2, columnspan = 1, padx=(5, 5), pady=(15, 0), sticky="ws")

        # кнопка старт
        self.button4 = customtkinter.CTkButton(self, fg_color="#3a689e", font=customtkinter.CTkFont(size=50), text_color_disabled="#383a3d",
                                                         text="Start", border_width=2, width=388, height=80,
                                               command = lambda: [self.reks(), self.Create_controllist(), self.button1.configure(state="enable")])
        self.button4.grid(row=4, rowspan = 1, column=0, columnspan = 3, padx=(82, 50), pady=(0, 0), sticky="wes")

        # поле показа введенных чисел      width=485, height=20,
        self.entry_numbers = customtkinter.CTkTextbox(self, activate_scrollbars = False, border_color="#3a689e",
                                                      border_width=20, width=500, height=350, font=customtkinter.CTkFont(size=28),
                                                      state="disabled", wrap="word")
        self.entry_numbers.grid(row=3, column=0, columnspan=3, padx=(50, 8), pady=(5, 12), sticky="new")
        self.entry_numbers.configure(font=customtkinter.CTkFont(size=28), text_color="#0aaa00")
        
        # обьявление времени
        self.logo_period = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=50), text=_("[ Жми старт! ]"))
        self.logo_period.grid(row=2, column=0, columnspan=2, padx=(50, 2), pady=(5, 2), sticky="sw")
        self.logo_period.configure(font=customtkinter.CTkFont(size=25), text_color="#ffffff")
        
        # обьявление уровня
        self.logo_field = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=22), text="")
        self.logo_field.grid(row=2, column=1, columnspan=4, padx=(2, 2), pady=(5, 2), sticky="sw")
        self.logo_field.configure(font=customtkinter.CTkFont(size=25), text_color="#ffffff")

        # прогрессбар футера 
        self.progressbar_20 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_20.grid(row=10, column=0, columnspan=8, padx=(20, 20), pady=(0, 5), sticky="sew")
        self.progressbar_20.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_20.start()

    # функция времени
    def reks(self):
        print("time = " + str(period))
        self.entry_numbers.configure(state="normal")
        self.button4.configure(state="disabled")
        if move_geme_progress[0] <= 0:
            self.after(1000, self.destroy)
            self.master.game_end()
        if controllist == []:
            self.master.play12()
            self.entry_numbers.delete("1.0", "end")
            self.result_time()
            self.entry_numbers.insert(END, str( "\n" + _("Скорее выбери первое число,") + "\n" + _("Время не ждет!")))
            self.after(10000, self.reks)
        if controllist > []:  #or controllist == [1]:
            if period >= [1]:
                self.after(1000, self.fask)
            else:
                if period <= [0] or shullte == [1]:
                    self.button4.configure(state="normal")
                else:
                    self.button4.configure(state="disabled")
                self.start_shullte()
                self.entry_numbers.delete("1.0", "end")
                self.entry_numbers.insert(END, str( "\n" + _("Время вышло! ") + "\n" + _("Жми старт! ")))
                self.entry_numbers.configure(state="disabled")
                self.button1.configure(state="disabled")
                a[0] = 0

    def fask(self):
        period[0] -= 1
        self.logo_period.configure(text = str(period))
        if controllist != arrangelist:
            self.reks()

    # уведомление о результате прохождения таблицы
    def result_time(self):
        if shullte == [2]:
            self.entry_numbers.insert(END, str( "\n" + _("Отлично!") + "\n" + _("Из предоставленных 30 секунд ") +
                                                "\n" + _(" было использованно ") + str(speed_time) + "\n"))
        if shullte == [3]:
            self.entry_numbers.insert(END, str( "\n" + _("Сила растет!") + "\n" + _("Из предоставленных 60 секунд ") +
                                                "\n" + _(" было использованно ") + str(speed_time) + "\n"))
        if shullte == [4]:
            self.entry_numbers.insert(END, str( "\n" + _("Это мощно!") + "\n" + _("Из предоставленных 90 секунд ") +
                                                "\n" + _(" было использованно ") + str(speed_time) + "\n"))
        if shullte == [5]:
            self.entry_numbers.insert(END, str( "\n" + _("Очень хорошо !") + "\n" + _("Из предоставленных 120 секунд ") +
                                                "\n" + _(" было использованно ") + str(speed_time) + "\n"))
        if shullte == [6]:
            self.entry_numbers.insert(END, str( "\n" + _("Невероятная мощь!") + "\n" + _("Из предоставленных 150 секунд ") +
                                                "\n" + _(" было использованно ") + str(speed_time) + "\n"))
        if shullte == [7]:
            self.entry_numbers.insert(END, str( "\n" + _("Великая победа!") + "\n" + _("Твоя концентрация выше гор ") +
                                                "\n" + _(" и шире морей! ") + _("Из предоставленных 150 секунд ") +
                                                "\n" + _(" было использованно ") + str(speed_time) + "\n"))
            
    # старт игры и смена уровня и время
    def start_shullte(self):
        global speed_time
        speed_time = []
        if shullte == [1]:
            print ('start_shullte1' + str(shullte))
            print("List for % shullte " + str(a[0]))
            self.Shullte_1()
            self.logo_field.configure(text=_("Уровень 1: числа от 1 до 25"))
            self.logo_period.configure(text = _("[ 30 секунд ]"))
        if shullte == [2]:
            print ('start_shullte2' + str(shullte))
            print("List for % shullte " + str(a[0]))
            period[0] -= 30
            speed_time = period[0]
            self.sidebar_frame1.destroy()
            self.Field()
            self.Shullte_2()
            self.result_time()
            self.logo_field.configure(text=_("Уровень 2: числа от 1 до 36"))
            self.logo_period.configure(text = _("[ 60 секунд ]"))
        if shullte == [3]:
            print ('start_shullte3' + str(shullte))
            print("List for % shullte " + str(a[0]))
            period[0] -= 60
            speed_time = period[0]
            self.sidebar_frame1.destroy()
            self.Field()
            self.Shullte_3()
            self.result_time()
            self.logo_field.configure(text=_("Уровень 3: числа от 1 до 49"))
            self.logo_period.configure(text = _("[ 90 секунд ]"))
        if shullte == [4]:
            print ('start_shullte4' + str(shullte))
            print("List for % shullte " + str(a[0]))
            period[0] -= 90
            speed_time = period[0]
            self.sidebar_frame1.destroy()
            self.Field()
            self.Shullte_4()
            self.logo_field.configure(text=_("Уровень 4: числа от 1 до 64"))
            self.logo_period.configure(text = _("[ 120 секунд ]"))
        if shullte == [5]:
            print ('start_shullte5' + str(shullte))
            print("List for % shullte " + str(a[0]))
            period[0] -= 120
            speed_time = period[0]
            self.sidebar_frame1.destroy()
            self.Field()
            self.Shullte_5()
            self.logo_field.configure(text=_("Уровень 5: числа от 1 до 81"))
            self.logo_period.configure(text = _("[ 150 секунд ]"))
        if shullte == [6]:
            print ('start_shullte6' + str(shullte))
            print("List for % shullte " + str(a[0]))
            period[0] -= 150
            speed_time = period[0]
            self.sidebar_frame1.destroy()
            self.Field()
            self.Shullte_6()
            self.logo_field.configure(text=_("Уровень 6: числа от 1 до 100"))
            self.logo_period.configure(text = _("[ 180 секунд ]"))
        if shullte == [7]:
            print ('start_shullte6' + str(shullte))
            print("List for % shullte " + str(a[0]))
            self.entry_numbers.insert(END, str( "\n" + _("Великая победа!") + "\n" + _("Твоя концентрация выше гор ") +
                                                "\n" + _(" и шире морей! ") + str(speed_time) + "\n"))
            a[0] = 0
            #self.video_file()
            self.after(10000, self.sullet_exit())
                      
    # создание таблицы 1
    def Shullte_1(self):
        
        global randomList
        randomList = []
        while len(randomList) != 25:
            for l in range(25):              
               r=random.randint(1,25)
               if r not in randomList:           
                  randomList.append(r)
        print (randomList)
        
        # деление списка на кортежи для строк
        global chunked_list
        chunk_size = 5
        chunked_list = [randomList[i:i+chunk_size] for i in range(0, len(randomList), chunk_size)]        
        self.Create_list()
        for i in range(total_rows):
            for j in range(total_columns):
                self.button100 = customtkinter.CTkButton(self.sidebar_frame1, border_width=2, corner_radius=0,
                               font=customtkinter.CTkFont(size=25, weight="bold"),
                               command = lambda num=(str(chunked_list[i][j])): self.Callback(num))
                self.button100.grid(row=i, column=j)
                self.button100.configure(text=(str(chunked_list[i][j])))
                self.button100.configure(width=124, height=124)
                
    # создание таблицы 2
    def Shullte_2(self):        
        global randomList
        randomList = []
        while len(randomList) != 36:
            for l in range(36):             
               r=random.randint(1,36)
               if r not in randomList:              
                  randomList.append(r)
        print (randomList)
        
        # деление списка на кортежи для строк
        global chunked_list
        chunk_size = 6
        chunked_list = [randomList[i:i+chunk_size] for i in range(0, len(randomList), chunk_size)]        
        self.Create_list()
        for i in range(total_rows):
            for j in range(total_columns):
                self.button100 = customtkinter.CTkButton(self.sidebar_frame1, border_width=2, corner_radius=0,
                               font=customtkinter.CTkFont(size=25, weight="bold"),
                               command = lambda num=(str(chunked_list[i][j])): self.Callback(num))
                self.button100.grid(row=i, column=j)
                self.button100.configure(text=(str(chunked_list[i][j])))
                self.button100.configure(width=103, height=103)
                
    # создание таблицы 3
    def Shullte_3(self):
        global randomList
        randomList = []
        while len(randomList) != 49:
            for l in range(49):      
               r=random.randint(1,49)
               if r not in randomList:         
                  randomList.append(r)
        print (randomList)
        
        # деление списка на кортежи для строк
        global chunked_list
        chunk_size = 7
        chunked_list = [randomList[i:i+chunk_size] for i in range(0, len(randomList), chunk_size)]        
        self.Create_list()
        for i in range(total_rows):
            for j in range(total_columns):
                self.button100 = customtkinter.CTkButton(self.sidebar_frame1, border_width=2, corner_radius=0,
                               font=customtkinter.CTkFont(size=25, weight="bold"),
                               command = lambda num=(str(chunked_list[i][j])): self.Callback(num))
                self.button100.grid(row=i, column=j)
                self.button100.configure(text=(str(chunked_list[i][j])))
                self.button100.configure(width=88, height=88)
                
    # создание таблицы 4
    def Shullte_4(self):
        global randomList
        randomList = []
        while len(randomList) != 64:
            for l in range(64):
               r=random.randint(1,64)
               if r not in randomList:  
                  randomList.append(r)
        print (randomList)
        
        # деление списка на кортежи для строк
        global chunked_list
        chunk_size = 8
        chunked_list = [randomList[i:i+chunk_size] for i in range(0, len(randomList), chunk_size)]        
        self.Create_list()
        for i in range(total_rows):
            for j in range(total_columns):
                self.button100 = customtkinter.CTkButton(self.sidebar_frame1, border_width=2, corner_radius=0,
                               font=customtkinter.CTkFont(size=25, weight="bold"),
                               command = lambda num=(str(chunked_list[i][j])): self.Callback(num))
                self.button100.grid(row=i, column=j)
                self.button100.configure(text=(str(chunked_list[i][j])))
                self.button100.configure(width=77, height=77)
                
    # создание таблицы 5
    def Shullte_5(self):
        global randomList
        randomList = []
        while len(randomList) != 81:
            for l in range(81):
               r=random.randint(1,81)
               if r not in randomList:
                  randomList.append(r)
        print (randomList)
        
        # деление списка на кортежи для строк
        global chunked_list
        chunk_size = 9
        chunked_list = [randomList[i:i+chunk_size] for i in range(0, len(randomList), chunk_size)]        
        self.Create_list()
        for i in range(total_rows):
            for j in range(total_columns):
                self.button100 = customtkinter.CTkButton(self.sidebar_frame1, border_width=2, corner_radius=0,
                               font=customtkinter.CTkFont(size=25, weight="bold"),
                               command = lambda num=(str(chunked_list[i][j])): self.Callback(num))
                self.button100.grid(row=i, column=j)
                self.button100.configure(text=(str(chunked_list[i][j])))
                self.button100.configure(width=68, height=68)
                
    # создание таблицы 6
    def Shullte_6(self):
        global randomList
        randomList = []
        while len(randomList) != 100:
            for l in range(100):
               r=random.randint(1,100)
               if r not in randomList:
                  randomList.append(r)
        print (randomList)
        
        # деление списка на кортежи для строк
        global chunked_list
        chunk_size = 10
        chunked_list = [randomList[i:i+chunk_size] for i in range(0, len(randomList), chunk_size)]        
        self.Create_list()
        for i in range(total_rows):
            for j in range(total_columns):
                self.button100 = customtkinter.CTkButton(self.sidebar_frame1, border_width=2, corner_radius=0,
                               font=customtkinter.CTkFont(size=25, weight="bold"),
                               command = lambda num=(str(chunked_list[i][j])): self.Callback(num))
                self.button100.grid(row=i, column=j)
                self.button100.configure(text=(str(chunked_list[i][j])))
                self.button100.configure(width=62, height=62)

    # создание списков
    def Create_list(self):
        # создание периода
        global period
        period = []
        if shullte == [1]:
            period = [30]
            print("time1 = " + str(period))
        if shullte == [2]:
            period = [60]
            print("time2 = " + str(period))
        if shullte == [3]:
            period = [90]
            print("time3 = " + str(period))
        if shullte == [4]:
            period = [120]
            print("time4 = " + str(period))
        if shullte == [5]:
            period = [150]
            print("time5 = " + str(period))
        if shullte == [6]:
            period = [180]
            print("time6 = " + str(period))

        # создание строк и колонок
        global total_rows
        global total_columns
        total_rows = len(chunked_list)
        total_columns = len(chunked_list[0])
        print (chunked_list)

        # создание сортированного списка
        global arrangelist 
        arrangelist = []
        arrangelist = sorted(randomList)
        print (arrangelist)

        # создание контрольного списка
        global controllist
        controllist = []
        print("controllist = " + str(controllist))

    # перезапись контрольного списка
    def Create_controllist(self):
        global controllist
        controllist = []
        print("controllist = " + str(controllist))
      
    # функция при выборе числа добавление в контрольный список сравнение с отсортированным списком и смена таблицы при выигрыше
    def Callback(self, num):
        print(num)
        controllist.append(int(num))
        self.entry_numbers.delete("1.0", "end")
        self.entry_numbers.insert(END, str(controllist))
        print("controllist = " + str(controllist))
        print(controllist == arrangelist)
        if controllist == arrangelist:            
            itern = a
            a[0] += 1000
            self.master.logo_info_status3.configure(text = str(itern))
            self.master.progressbar_6.set(self.master.progressbar_6.get() + mass_4)
            if shullte == [1]:
                a[0] += 1000
                print("List for % shullte " + str(a[0]))
            if shullte == [2]:
                a[0] += 2000
                print("List for % shullte " + str(a[0]))
            if shullte == [3]:
                a[0] += 3000
                print("List for % shullte " + str(a[0]))
            if shullte == [4]:
                a[0] += 4000
                print("List for % shullte " + str(a[0]))
            if shullte == [5]:
                a[0] += 5000
                print("List for % shullte " + str(a[0]))
            if shullte == [6]:
                a[0] += 6000
                print("List for % shullte " + str(a[0]))
            print(controllist == arrangelist)
            self.master.select_player()
            self.master.countdown()
            self.master.game_selection()      
            self.master.play6()
            shullte[0] += 1
            print ('shullte - Callback' + str(shullte))
            self.Restart()
        else:
            self.master.play10()

    # отмена выбора числа
    def cancel_number(self):
        del controllist[-1:]
        print ('cancel_number' + str(controllist))
        a[0] = 0
        self.entry_numbers.delete("1.0", "end")
        self.entry_numbers.insert(END, str(controllist))
                
    # рестарт
    def Restart(self):
        if period <= [0] or shullte == [1]:
            self.button4.configure(state="normal")
        else:
            self.button4.configure(state="disabled")
        self.start_shullte()
        self.entry_numbers.delete("1.0", "end")
        self.entry_numbers.configure(state="disabled")
        a[0] = 0

    # выход из шульте
    def sullet_exit(self):
        self.master.play3()
        a[0] = 0
        self.after(1000, self.destroy)
      
# окно завершения программы       
class Toplevel1Window(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.title(_("Выход из игры")) 
        self.geometry("1020x580")
        self.label = customtkinter.CTkLabel(self, text=_("Хорошо подумал?"), font=customtkinter.CTkFont(size=55, weight="bold"))
        self.label.pack(padx=20, pady=(28, 12))
        self.button_24 = customtkinter.CTkButton(self, text=_("      Хорошо!      "),
                                                 font=customtkinter.CTkFont(size=55, weight="bold"), border_width=2, command=quit)
        self.button_24.pack(expand=True)
        self.button_88 = customtkinter.CTkButton(self, text=_("Подумаю еще...") ,
                                                 font=customtkinter.CTkFont(size=55, weight="bold"), border_width=2, command=self.destroy)
        self.button_88.pack(side="right", padx=(5, 28), pady=(5, 20))
        
# окно уведомления следующего уровня    
class Toplevel2Window(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.title(_("Следующий уровень"))
        self.geometry("320x120")
        App.play0(self)
        self.label = customtkinter.CTkLabel(self, text=_('Повышение уровня!') +'\n'+ _('Нейронные связи настраиваются!'), font=customtkinter.CTkFont(size=55, weight="bold"))
        self.label.pack(expand=True)
        self.canvas_16 = Canvas(self, bg = "#3a689e", height = 280, width = 500)
        self.canvas_16.pack(padx=20, pady=(12, 12))
        self.ava_16 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/level_up.png")
        self.ava_img_16 = self.canvas_16.create_image(1, 1, anchor=NW, image = self.ava_16)
        self.button_25 = customtkinter.CTkButton(self, text=_("Ok!") ,font=customtkinter.CTkFont(size=55, weight="bold"), border_width=2,
                                                 command = self.destroy)
        self.button_25.pack(expand=True)

# окно правил   
class Toplevel3Window(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        #self.attributes('-zoomed', True)
        #self.wm_attributes('-type', 'splash')
        my_font = customtkinter.CTkFont(size=18)
        Toplevel3Window.columnconfigure(self, 0, weight=0)
        Toplevel3Window.columnconfigure(self, 1, weight=1)
        Toplevel3Window.rowconfigure(self, 0, weight=1)
        self.title(_("Правила"))
        #self.geometry("1020x500")
        if lang_txt == [0]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text/concept.txt").read()
        if lang_txt == [1]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/concept.txt").read()
        if lang_txt == [2]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/concept.txt").read()
        if lang_txt == [3]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/concept.txt").read()
        if lang_txt == [4]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/concept.txt").read()
        if lang_txt == [5]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/concept.txt").read()
        if lang_txt == [6]:
            file0 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/concept.txt").read()
             
        if lang_txt == [0]:
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text/basic_rules.txt").read()
        if lang_txt == [1]:    
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/basic_rules.txt").read()
        if lang_txt == [2]:
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/basic_rules.txt").read()
        if lang_txt == [3]:
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/basic_rules.txt").read()
        if lang_txt == [4]:
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/basic_rules.txt").read()
        if lang_txt == [5]:
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/basic_rules.txt").read()
        if lang_txt == [6]:
            file1 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/basic_rules.txt").read()
             
        if lang_txt == [0]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text/intuition.txt").read()
        if lang_txt == [1]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/intuition.txt").read()
        if lang_txt == [2]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/intuition.txt").read()
        if lang_txt == [3]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/intuition.txt").read()
        if lang_txt == [4]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/intuition.txt").read()
        if lang_txt == [5]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/intuition.txt").read()
        if lang_txt == [6]:
            file2 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/intuition.txt").read()
             
        if lang_txt == [0]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text/memory.txt").read()
        if lang_txt == [1]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/memory.txt").read()
        if lang_txt == [2]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/memory.txt").read()
        if lang_txt == [3]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/memory.txt").read()
        if lang_txt == [4]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/memory.txt").read()
        if lang_txt == [5]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/memory.txt").read()
        if lang_txt == [6]:
            file3 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/memory.txt").read()
             
        if lang_txt == [0]:   
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text/concentration.txt").read()
        if lang_txt == [1]:   
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/concentration.txt").read()
        if lang_txt == [2]:
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/concentration.txt").read()
        if lang_txt == [3]:
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/concentration.txt").read()
        if lang_txt == [4]:
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/concentration.txt").read()
        if lang_txt == [5]:
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/concentration.txt").read()
        if lang_txt == [6]:
            file4 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/concentration.txt").read()
             
        if lang_txt == [0]:     
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text/labyrinth.txt").read()
        if lang_txt == [1]:     
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/labyrinth.txt").read()
        if lang_txt == [2]:
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/labyrinth.txt").read()
        if lang_txt == [3]:
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/labyrinth.txt").read()
        if lang_txt == [4]:
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/labyrinth.txt").read()
        if lang_txt == [5]:
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/labyrinth.txt").read()
        if lang_txt == [6]:
            file5 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/labyrinth.txt").read()
             
        if lang_txt == [0]:  
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text/about_the_game.txt").read()
        if lang_txt == [1]:  
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/about_the_game.txt").read()
        if lang_txt == [2]:
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text_en/about_the_game.txt").read()
        if lang_txt == [3]:
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text_es/about_the_game.txt").read()
        if lang_txt == [4]:
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/about_the_game.txt").read()
        if lang_txt == [5]:
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/about_the_game.txt").read()
        if lang_txt == [6]:
            file6 = open("/home/lord/MEGAsync/books/python/Oracl/text_de/about_the_game.txt").read()
             
        self.label = customtkinter.CTkLabel(self, text=_("Добро пожаловать в руководство по игре"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.grid(row=1, column=0, columnspan=10, padx=(0, 0), pady=(2, 2), sticky="ns")
        self.button_26 = customtkinter.CTkButton(self, text=_("Понятно") ,font=customtkinter.CTkFont(size=22, weight="bold"), border_width=2,
                                                          width=88, height=55, command = self.destroy)
        self.button_26.grid(row=5, column=0, columnspan=10, padx=(0, 0), pady=(2, 2), sticky="ns")
        self.tabview = customtkinter.CTkTabview(self, width=1200, height =588, corner_radius=5,
                                                border_color="#454545", segmented_button_selected_color="#3a689e", border_width=2)
        self.tabview.grid(row=2, column=0, columnspan=10, rowspan=1, padx=(15, 15), pady=(2, 8), sticky="ns")
        self.tabview.add(_("            Концепт            "))
        self.tabview.add(_("            Основные правила            "))
        self.tabview.add(_("            Интуиция            "))
        self.tabview.add(_("            Память            "))
        self.tabview.add(_("        Концентрация        "))
        self.tabview.add(_("            Лабиринт            "))
        self.tabview.add(_("            Об игре            "))
        for button in self.tabview._segmented_button._buttons_dict.values():
            button.configure(width=58, height=58, font=my_font)
            
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("            Концепт            ")),
                                                width=1000, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(20, 20), pady=(2, 8), sticky="ns")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file0 )
        
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("            Основные правила            ")),
                                                width=385, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(8, 8), pady=(2, 5), sticky="nws")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file1 )
        
        self.canvas_11 = Canvas(self.tabview.tab(_("            Основные правила            ")), bg = "#3a689e", height = 500, width = 750)
        self.canvas_11.grid(row=1, column=1, columnspan=1, padx=(2, 2), pady=(2, 5), sticky="nse")
        self.ava_11 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/basic_rules.png")
        self.ava_img_11 = self.canvas_11.create_image(1,1, anchor=NW, image = self.ava_11)
        
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("            Интуиция            ")),
                                                width=385, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(8, 8), pady=(2, 5), sticky="news")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file2 )
        
        self.canvas_12 = Canvas(self.tabview.tab(_("            Интуиция            ")), bg = "#3a689e", height = 500, width = 750)
        self.canvas_12.grid(row=1, column=1, columnspan=1, padx=(2, 2), pady=(2, 5), sticky="nsw")
        self.ava_12 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/intuition.png")
        self.ava_img_12 = self.canvas_12.create_image(1,1, anchor=NW, image = self.ava_12)
        
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("            Память            ")),
                                                width=385, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(8, 8), pady=(2, 5), sticky="news")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file3 )
        
        self.canvas_13 = Canvas(self.tabview.tab(_("            Память            ")), bg = "#3a689e", height = 500, width = 750)
        self.canvas_13.grid(row=1, column=1, columnspan=1, padx=(2, 2), pady=(2, 5), sticky="nsw")
        self.ava_13 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/memory.png")
        self.ava_img_13 = self.canvas_13.create_image(1,1, anchor=NW, image = self.ava_13)
        
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("        Концентрация        ")),
                                                width=385, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(8, 8), pady=(2, 5), sticky="news")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file4 )
        
        self.canvas_14 = Canvas(self.tabview.tab(_("        Концентрация        ")), bg = "#3a689e", height = 500, width = 750)
        self.canvas_14.grid(row=1, column=1, columnspan=1, padx=(2, 2), pady=(2, 5), sticky="nsw")
        self.ava_14 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/concentration.png")
        self.ava_img_14 = self.canvas_14.create_image(1,1, anchor=NW, image = self.ava_14)
        
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("            Лабиринт            ")),
                                                width=385, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(8, 8), pady=(2, 5), sticky="news")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file5 )
        
        self.canvas_15 = Canvas(self.tabview.tab(_("            Лабиринт            ")), bg = "#3a689e", height = 500, width = 750)
        self.canvas_15.grid(row=1, column=1, columnspan=1, padx=(2, 2), pady=(2, 5), sticky="nsw")
        self.ava_15 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/labyrinth.png")
        self.ava_img_15 = self.canvas_15.create_image(1,1, anchor=NW, image = self.ava_15)
        
        self.textbox = customtkinter.CTkTextbox(self.tabview.tab(_("            Об игре            ")),
                                                width=1000, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(20, 20), pady=(2, 8), sticky="nse")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), wrap="word")
        self.textbox.insert(0.0, file6 )

# окно показа чисел карты    
class Toplevel4Window(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.title(_("Запомни число"))
        self.geometry("380x220")
        self.label = customtkinter.CTkLabel(self, text=_("Случайное число карты"), font=customtkinter.CTkFont(size=55, weight="bold"))
        self.label.pack(padx=20, pady=(15, 15))
        self.label2 = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=58))
        self.label2.pack(expand=True)
        self.button_35 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=55, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_35.pack(padx=20, pady=(20, 20))
        self.after(8000, self.destroy) 
        self.label_card_num()
        
    def label_card_num(self):
        if Level2 == _("4 цифры (разминка)"):               
            self.label2.configure(text= str(Card_num_1))
        if Level2 == _("6 цифр (легко)"):                    
            self.label2.configure(text= str(Card_num_1) + " " + str(Card_num_2))
        if Level2 == _("8 цифр (средне)"):                                                               
            self.label2.configure(text= str(Card_num_1) + " " + str(Card_num_2) + " " + str(Card_num_3))
        if Level2 == _("10 цифр (норма)") or Level2 ==_("12 цифр (сложно)") or Level2 == _("16 цифр (круто)"):  
            self.label2.configure(text= str(Card_num_1) + " " + str(Card_num_2) + " " + str(Card_num_3) + " " + str(Card_num_4))

# окно совета    
class Toplevel5Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.title(_("Не угадал"))
        self.geometry("380x280")
        self.label = customtkinter.CTkLabel(self, font=customtkinter.CTkFont(size=58, weight="bold"))
        self.label.pack(padx=20, pady=(15, 15))
        self.label.configure(text = _("Народная мудрость"))
        self.textbox = customtkinter.CTkTextbox(self, width=880, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.pack(padx=(20, 20), pady=(2, 2))
        self.textbox.configure(font=customtkinter.CTkFont(size=50), wrap="word")
        self.buttonMylist()
        self.after(28000, self.destroy)
        self.button_31 = customtkinter.CTkButton(self, text=_("Понятно") ,font=customtkinter.CTkFont(size=58, weight="bold"), border_width=2,
                                                 command = self.destroy)
        self.button_31.pack(padx=(28, 5), pady=(18, 20))
        
    # вывод файла на монитор текста
    def buttonMylist(self):
        print("buttonMylist")
        global Mylist
        global Max
        #Max = 0
        print("buttonMylist called")
        self.master.loadMylist()
        Nr = random.randint(0,201)
        print("Nr = ", Nr) 
        print("Mylist = ", Mylist) 
        if Nr <= Max and len(Mylist) > Nr: 
            self.textbox.delete("1.0", "end")
            self.textbox.insert("1.0", Mylist[Nr])
        else:
            self.textbox.delete("1.0", "end")
            self.textbox.insert("1.0", _("Нет ничего интерессного..."))
            print("Нет строк для вывода")

# окно описания игрок 1 
class Toplevel6Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.title(_("Игрок 1"))
        self.geometry("555x350")
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/player1.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/player1.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/player1.txt").read()
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/player1.txt").read()
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/player1.txt").read()
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/player1.txt").read()
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/player1.txt").read()
            
        self.label = customtkinter.CTkLabel(self, text=_("Psyheiya"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.grid(row=0, column=0, columnspan=2, padx=(2, 2), pady=(5, 5), sticky="nswe")
        self.canvas_4 = Canvas(self, bg = "#3a689e", height = 580, width = 580)
        self.canvas_4.grid(row=1, column=0, columnspan=1, padx=(58, 2), pady=(5, 2), sticky="nsw")
        self.ava_4 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava1.3.png")
        self.ava_img_4 = self.canvas_4.create_image(291,291, anchor=CENTER, image = self.ava_4)
        self.textbox = customtkinter.CTkTextbox(self, width=500, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=1, columnspan=1, padx=(5, 50), pady=(5, 2), sticky="nswe")
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_32 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=38, weight="bold"), width=55, height=15, 
                                                 border_width=2, command = self.destroy)
        self.button_32.grid(row=2, column=0, columnspan=2, pady=20, sticky="n")

# окно описания игрок 2 
class Toplevel7Window(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.title(_("Игрок 2"))
        self.geometry("555x350")
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/player2.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/player2.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/player2.txt").read()   
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/player2.txt").read()   
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/player2.txt").read()   
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/player2.txt").read()   
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/player2.txt").read()   
            
        self.label = customtkinter.CTkLabel(self, text=_("Golem"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.grid(row=0, column=0, columnspan=2, padx=(2, 2), pady=(5, 5), sticky="nswe")
        self.canvas_5 = Canvas(self, bg = "#3a689e", height = 580, width = 580)
        self.canvas_5.grid(row=1, column=0, columnspan=1, padx=(58, 2), pady=(5, 2), sticky="nsw")
        self.ava_5 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava2.3.png")
        self.ava_img_5 = self.canvas_5.create_image(291,291, anchor=CENTER, image = self.ava_5)
        self.textbox = customtkinter.CTkTextbox(self, width=500, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=1, columnspan=1, padx=(15, 50), pady=(5, 2), sticky="nswe")
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_33 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=38, weight="bold"), width=55, height=15, 
                                                 border_width=2, command = self.destroy)
        self.button_33.grid(row=2, column=0, columnspan=2, pady=20, sticky="n")

# окно описания игрок 3 
class Toplevel8Window(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.title(_("Игрок 3"))
        self.geometry("555x350")
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/player3.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/player3.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/player3.txt").read()  
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/player3.txt").read()  
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/player3.txt").read()  
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/player3.txt").read()  
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/player3.txt").read()  
            
        self.label = customtkinter.CTkLabel(self, text=_("Expand"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.grid(row=0, column=0, columnspan=2, padx=(2, 2), pady=(5, 5), sticky="nswe")
        self.canvas_6 = Canvas(self, bg = "#3a689e", height = 580, width = 580)
        self.canvas_6.grid(row=1, column=0, columnspan=1, padx=(58, 2), pady=(5, 2), sticky="nsw")
        self.ava_6 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava3.3.png")
        self.ava_img_6 = self.canvas_6.create_image(291,291, anchor=CENTER, image = self.ava_6)
        self.textbox = customtkinter.CTkTextbox(self, width=500, height=500, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.grid(row=1, column=1, columnspan=1, padx=(15, 50), pady=(5, 2), sticky="nswe")
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_34 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=38, weight="bold"), width=55, height=15, 
                                                 border_width=2, command = self.destroy)
        self.button_34.grid(row=2, column=0, columnspan=2, pady=20, sticky="n")

# окно победы 
class Toplevel9Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.title(_("Победа"))
        self.geometry("555x555")
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/wins.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/wins.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/wins.txt").read()       
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/wins.txt").read()       
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/wins.txt").read()       
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/wins.txt").read()       
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/wins.txt").read()       
            
        self.label = customtkinter.CTkLabel(self, text=_("Вот это да!"), font=customtkinter.CTkFont(size=55, weight="bold"))
        self.label.pack(padx=20, pady=(20, 12))
        self.canvas_7 = Canvas(self, bg = "#3a689e", height = 280, width = 280)
        self.canvas_7.pack(padx=20, pady=(12, 12))
        self.ava_7 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/wins.png")
        self.ava_img_7 = self.canvas_7.create_image(1, 1, anchor=NW, image = self.ava_7)
        self.textbox = customtkinter.CTkTextbox(self, width=428, height=150, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.pack(padx=20, pady=(12, 12))
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_35 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=55, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_35.pack(padx=20, pady=(12, 20))

# окно поражения при наборе штрафов
class Toplevel10Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.master.play12()
        self.title(_("Поражение"))
        self.geometry("555x555")
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/end.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/end.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/end.txt").read()          
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/end.txt").read()          
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/end.txt").read()          
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/end.txt").read()          
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/end.txt").read()          
            
        self.label = customtkinter.CTkLabel(self, text=_("Ну это перебор"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.pack(padx=20, pady=(5, 5))
        self.canvas_8 = Canvas(self, bg = "#3a689e", height = 280, width = 280)
        self.canvas_8.pack(padx=20, pady=(12, 12))
        self.ava_8 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/end.png")
        self.ava_img_8 = self.canvas_8.create_image(1, 1, anchor=NW, image = self.ava_8)
        self.textbox = customtkinter.CTkTextbox(self, width=880, height=220, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.pack(padx=20, pady=(12, 12))
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_36 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=55, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_36.pack(padx=20, pady=(12, 20))

# окно поражения при окончании бодрости
class Toplevel13Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.master.play12()
        self.title(_("Поражение"))
        self.geometry("555x555")
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/end2.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/end2.txt").read()       
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/end2.txt").read()
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/end2.txt").read()                   
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/end2.txt").read()                   
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/end2.txt").read()                   
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/end2.txt").read()                   
            
        self.label = customtkinter.CTkLabel(self, text=_("Игроки полностью выдохлись"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.pack(padx=20, pady=(5, 5))
        self.canvas_9 = Canvas(self, bg = "#3a689e", height = 280, width = 280)
        self.canvas_9.pack(padx=20, pady=(12, 12))
        self.ava_9 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/out_of_power.png")
        self.ava_img_9 = self.canvas_9.create_image(1, 1, anchor=NW, image = self.ava_9)
        self.textbox = customtkinter.CTkTextbox(self, width=880, height=220, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.pack(padx=20, pady=(12, 12))
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_36 = customtkinter.CTkButton(self, text=_("Понятно"), font=customtkinter.CTkFont(size=55, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_36.pack(padx=20, pady=(12, 20))

# окно смены языка
class Toplevel14Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.title(_("Перевод"))
        self.geometry("555x555")
        self.grid_columnconfigure((0,1,2,3,4,5,6,7), weight=1)
        self.grid_rowconfigure((0,1,2), weight=1)
        self.label = customtkinter.CTkLabel(self, text=_("При смене языка произойдет сброс игры "), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.grid(row=0, column=0, columnspan=7, padx=(0, 0), pady=(0, 0), sticky="ew")
        self.sidebar_button_81 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("zh"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("zh"),
                                 self.master.translater_txt_zh(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])
        self.sidebar_button_81.grid(row=1, column=0, padx=(12, 0), pady=(0, 0))        
        self.sidebar_button_82 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("ru"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("ru"),
                                 self.master.translater_txt_ru(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])
        self.sidebar_button_82.grid(row=1, column=1, padx=(0, 0), pady=(0, 0))        
        self.sidebar_button_83 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("es"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("es"),
                                 self.master.translater_txt_es(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])
        self.sidebar_button_83.grid(row=1, column=2, padx=(0, 0), pady=(0, 0))        
        self.sidebar_button_84 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("en"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("en"),
                                 self.master.translater_txt_en(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])
        self.sidebar_button_84.grid(row=1, column=3, padx=(0, 0), pady=(0, 0))        
        self.sidebar_button_85 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("pt"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("pt"),
                                 self.master.translater_txt_pt(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])
        self.sidebar_button_85.grid(row=1, column=4, padx=(0, 0), pady=(0, 0))
        self.sidebar_button_86 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("fr"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("fr"),
                                 self.master.translater_txt_fr(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])                 
        self.sidebar_button_86.grid(row=1, column=5, padx=(0, 0), pady=(0, 0))   
        self.sidebar_button_87 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text=_("de"),border_width=20, border_color ="#FFFFFF", font=customtkinter.CTkFont(size=80), width=180, height=180,
                 command=lambda:[self.master.play3(), self.master.start_hide_widget(), select_language("de"),
                                 self.master.translater_txt_de(), self.master.big_body(), self.destroy(), self.master.open_toplevel15()])                 
        self.sidebar_button_87.grid(row=1, column=6, padx=(0, 0), pady=(0, 0))        
        self.button_188 = customtkinter.CTkButton(self, text=_("Закрыть"), font=customtkinter.CTkFont(size=50, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_188.grid(row=2, column=0, columnspan=7, padx=(0, 0), pady=(0, 0))
        
# окно старта
class Toplevel15Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.title(_("Начало"))
        self.geometry("555x555")
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/start.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/start.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/start.txt").read()           
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/start.txt").read()           
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/start.txt").read()
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/start.txt").read()
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/start.txt").read()
             
        self.label = customtkinter.CTkLabel(self, text=_("Прямо сейчас... "), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.pack(padx=20, pady=(5, 2))
        self.canvas_9 = Canvas(self, bg = "#3a689e", height = 335, width = 800)
        self.canvas_9.pack(padx=20, pady=(5, 2))
        self.ava_9 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/start.png")
        self.ava_img_9 = self.canvas_9.create_image(1, 1, anchor=NW, image = self.ava_9)
        self.textbox = customtkinter.CTkTextbox(self, width=880, height=200, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.pack(padx=20, pady=(5, 12))
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        
        self.button_36 = customtkinter.CTkButton(self, text=_("Начать"), font=customtkinter.CTkFont(size=55, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_36.pack(padx=20, pady=(12, 20))

# окно финиша
class Toplevel16Window(customtkinter.CTkToplevel):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.attributes('-zoomed', True)
        self.wm_attributes('-type', 'splash')
        self.master = master
        self.master.play12()
        self.title(_("Финиш"))
        self.geometry("555x555")
        if lang_txt == [0]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text/finish.txt").read()
        if lang_txt == [1]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/finish.txt").read()
        if lang_txt == [2]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_en/finish.txt").read()
        if lang_txt == [3]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_es/finish.txt").read()                         
        if lang_txt == [4]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/finish.txt").read()                         
        if lang_txt == [5]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/finish.txt").read()                         
        if lang_txt == [6]:
            file = open("/home/lord/MEGAsync/books/python/Oracl/text_de/finish.txt").read()                         
            
        self.label = customtkinter.CTkLabel(self, text=_("Наши поздравления!!!"), font=customtkinter.CTkFont(size=50, weight="bold"))
        self.label.pack(padx=20, pady=(5, 2))
        self.canvas_9 = Canvas(self, bg = "#3a689e", height = 335, width = 335)
        self.canvas_9.pack(padx=20, pady=(5, 2))
        self.ava_9 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/finish.png")
        self.ava_img_9 = self.canvas_9.create_image(1, 1, anchor=NW, image = self.ava_9)
        self.textbox = customtkinter.CTkTextbox(self, width=880, height=200, corner_radius=5, border_color="#6489ad", border_width=5)
        self.textbox.pack(padx=20, pady=(5, 12))
        self.textbox.configure(font=customtkinter.CTkFont(size=28), wrap="word")
        self.textbox.insert(0.0, file )
        self.button_37 = customtkinter.CTkButton(self, text=_("Продолжить"), font=customtkinter.CTkFont(size=55, weight="bold"), width=55, height=25, 
                                                 border_width=2, command = self.destroy)
        self.button_37.pack(padx=20, pady=(12, 20))
        
# ОСНОВНОЕ ОКНО
customtkinter.set_appearance_mode("Dark")  # модификация: "System", "Dark", "Light"
customtkinter.set_default_color_theme("dark-blue")  # тема: "blue", "green", "dark-blue"

# переменная перевода  # не удалять
#es = gettext.translation('base', localedir='locales', languages=['es'])
#es.install()
#zh = gettext.translation('base', localedir='locales', languages=['zh'])
#zh.install()
#en = gettext.translation('base', localedir='locales', languages=['en'])
#en.install()
#hi = gettext.translation('base', localedir='locales', languages=['hi'])
#hi.install()
#pt = gettext.translation('base', localedir='locales', languages=['pt'])
#pt.install()
#fr = gettext.translation('base', localedir='locales', languages=['fr'])
#fr.install()
#de = gettext.translation('base', localedir='locales', languages=['de'])
#de.install()
# не удалять
#_ = es.gettext      # Español           
#_ = zh.gettext      # 中文, 汉语   	
#_ = en.gettext      # English  
#_ = hi.gettext      # हिन्दी    
#_ = pt.gettext      # Português   
#_ = fr.gettext      # Français   
#_ = de.gettext      # Deutsch  
#_ = gettext.gettext

class App(customtkinter.CTk):
    def __init__(self, master=None, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        
        # запуск основной программы и основного перевода    
        self.big_body()
        self.s_translater_txt()
        
    # основная программа
    def big_body(self):    
        
        #self.wm_iconbitmap("icon_1.ico")

        self.state('normal')
        
        # окно
        self.title(_("Тренажер для мозга"))
        self.geometry(f"{1360}x{760}")
        
        # полноэкранный режим для виндовс
        #self.attributes('-fullscreen', True)
        #self.bind("<Space>", lambda event: [self.destroy()])

        # полноэкранный режим для linux
        #self.attributes('-zoomed', True)
        #self.wm_attributes('-type', 'splash')
        #self.bind("<Space>", lambda event: [self.destroy()])
        
        self.protocol("WM_DELETE_WINDOW", self.game_delete)

        # звуки старта       
        pygame.mixer.init()
        #self.play1()
        self.play0()
 
        # переменные        НАВЕСТИ ПОРЯДОК В ЭТОМ ХАОСЕ
        global Mylist
        Mylist = []        
        global Attempt
        Attempt = 0
        #global Stat
        Stat = 0
        guessed_number = customtkinter.StringVar()
        Max = 0
        Case = 0
        global a
        a = [0]
        global levelscore
        levelscore = [0]
        global move_geme_progress
        move_geme_progress = [100000]
        global mass_1, mass_2, mass_3, mass_4
        mass_1 = 0
        mass_2 = 0
        mass_3 = 0
        mass_4 = 0
        global game_selection
        game_selection = 0
        global select_player
        select_player = 0
        global amount
        amount = 0
        global balanser_reset
        balanser_reset = 0
 
        # макет сетки окна
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=0)
        self.grid_columnconfigure(2, weight=0)
        self.grid_columnconfigure(3, weight=0)
        self.grid_columnconfigure(4, weight=1)
        self.grid_columnconfigure(9, weight=0)
        self.grid_rowconfigure(1, weight=0)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self.grid_rowconfigure(4, weight=0)
        self.grid_rowconfigure(5, weight=0)
        self.grid_rowconfigure(6, weight=0)
        self.grid_rowconfigure(7, weight=0)
        
        # заголовок
        self.logo_label_title = customtkinter.CTkLabel(self, text=_("ВЕЛИКИЙ СУПЕР КОМПЬЮТЕР"), font=customtkinter.CTkFont(size=28, weight="bold"))
        self.logo_label_title.grid(row=0, column=4, padx=(25, 2), pady=(5, 5), sticky="nsew")

        # кнопка выбора языка
        self.sidebar_button_80 = customtkinter.CTkButton(self, fg_color="#3a689e",
                                                         text= "译文" ,border_width=2, font=customtkinter.CTkFont(size=20), width=20, height=20,
                 command=lambda:[self.play3(), self.open_toplevel14()])
        self.sidebar_button_80.grid(row=0, column=9, padx=(0, 20), pady=(0, 0), sticky="e")

        # прогрессбар хедера 1
        self.progressbar_7 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_7.grid(row=0, column=0, columnspan=10, padx=(20, 20), pady=(2, 2), sticky="sew")
        self.progressbar_7.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_7.start()
        
        # прогрессбар хедера 2
        self.progressbar_8 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_8.grid(row=0, column=0, columnspan=10, padx=(20, 20), pady=(2, 2), sticky="new")
        self.progressbar_8.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_8.start()
        
        # верхняя панель
        self.sidebar0_frame = customtkinter.CTkFrame(self, width=120, height=20, corner_radius=5, border_width=2, border_color="#454545")
        self.sidebar0_frame.grid(row=1, column=1, columnspan=8, padx=(2, 2), pady=(0, 2), sticky="nsew")
        self.sidebar0_frame.grid_columnconfigure((1,3,4,5,6,7,8), weight=0)
        self.sidebar0_frame.grid_columnconfigure((2), weight=1)
        
        # лейбл инфо статус
        self.logo_info = customtkinter.CTkLabel(self.sidebar0_frame,
                       text=_("Пройди все испытания и получи ответ")+ "\n" + _("            о смысле жизни, вселенной... и все такое..."),
                                                font=customtkinter.CTkFont(size=25))
        self.logo_info.grid(row=0, column=1, columnspan=1, padx=(2, 2), pady=(2, 2), sticky="nsw")
        self.logo_info.configure(font=customtkinter.CTkFont(size=28), text_color="#a553cb")
        
        # лейбл очков прохождения уровня
        self.logo_info_status1 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=20), text="")
        self.logo_info_status1.grid(row=0, column=5, columnspan=1, padx=(2, 2), pady=(2, 2), sticky="nse")
        self.logo_info_status1.configure(font=customtkinter.CTkFont(size=28), text_color="#cbad00")

        # лейбл названия очков уровня
        self.logo_info_status11 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=12), text="")
        self.logo_info_status11.grid(row=1, column=5, columnspan=1, padx=(2, 8), pady=(0, 5), sticky="nse")
        self.logo_info_status11.configure(font=customtkinter.CTkFont(size=18), text_color="#cbad00")
        
        # лейбл очков штрафа
        self.logo_info_status2 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=20), text="")
        self.logo_info_status2.grid(row=0, column=6, columnspan=1, padx=(2, 2), pady=(2, 2), sticky="nse")
        self.logo_info_status2.configure(font=customtkinter.CTkFont(size=28), text_color="#dc2525")

        # лейбл названия очков штрафа
        self.logo_info_status12 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=12), text="")
        self.logo_info_status12.grid(row=1, column=6, columnspan=1, padx=(2, 8), pady=(0, 5), sticky="nse")
        self.logo_info_status12.configure(font=customtkinter.CTkFont(size=18), text_color="#dc2525")

        # лейбл очков прохождения игры
        self.logo_info_status3 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=20), text="")
        self.logo_info_status3.grid(row=0, column=7, columnspan=1, padx=(2, 2), pady=(2, 2), sticky="nse")
        self.logo_info_status3.configure(font=customtkinter.CTkFont(size=28), text_color="#0aaa00")

        # лейбл названия очков прохождения игры
        self.logo_info_status13 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=12), text="")
        self.logo_info_status13.grid(row=1, column=7, columnspan=1, padx=(2, 8), pady=(0, 5), sticky="nse")
        self.logo_info_status13.configure(font=customtkinter.CTkFont(size=18), text_color="#0aaa00")
        
        # лейбл очков оставшихся ходов
        self.logo_info_status4 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=20), text="")
        self.logo_info_status4.grid(row=0, column=8, columnspan=1, padx=(2, 8), pady=(2, 2), sticky="nse")
        self.logo_info_status4.configure(font=customtkinter.CTkFont(size=28), text_color="#24ccea")

        # лейбл названия очков оставшихся ходов
        self.logo_info_status14 = customtkinter.CTkLabel(self.sidebar0_frame, font=customtkinter.CTkFont(size=18), text="")
        self.logo_info_status14.grid(row=1, column=8, columnspan=1, padx=(2, 12), pady=(0, 5), sticky="nse")
        self.logo_info_status14.configure(font=customtkinter.CTkFont(size=18), text_color="#24ccea")
     
        # монитор текста
        self.textbox = customtkinter.CTkTextbox(self, width=252, corner_radius=5, border_color="#3a689e", border_width=15, activate_scrollbars = True)
        self.textbox.grid(row=2, column=4, columnspan=1, rowspan=3, padx=(5, 5), pady=(2, 2), sticky="nsew")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), text_color="#5d94d5", wrap="word")
        self.textbox.insert("0.0", _(" Доброго времени тебе!") + "\n\n" + _("1. Прочитай правила") + "\n" + _("2. Выбери игрока")
                            + "\n" + _("3. Выбери игру") + "\n" +
                            _(" Прокачай интуицию, память, концетрацию, и обрети невероятные способности пройдя лабиринт. ")+ "\n" + 
                            _(" Или самозабвенно жуй сопли дальше...  "))

        # поле ввода
        self.entry = customtkinter.CTkEntry(self, textvariable=guessed_number, height=80,
                              border_width=5, border_color="#3a689e", font=customtkinter.CTkFont(size=50, weight="bold"))
        self.entry.grid(row=5, column=4, columnspan=1, padx=(80, 5), pady=(2, 2), sticky="swen")

        # левая боковая панель
        self.sidebar1_frame = customtkinter.CTkFrame(self, width=580, corner_radius=5, border_width=2, border_color="#454545")
        self.sidebar1_frame.grid(row=1, column=0, rowspan=7, padx=(5, 2), sticky="nsew")
        self.sidebar1_frame.grid_rowconfigure((1,2,3,4,5,6), weight=0)
        self.sidebar1_frame.grid_rowconfigure(7, weight=1)
        
        # кнопка игра 1 интуиция
        self.sidebar_button_11 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e",
                                                         text=_("Интуиция"),border_width=2, font=customtkinter.CTkFont(size=28), width=220, height=58,
                                 command=lambda:[self.new_game(), self.clear_form(), self.hide_widget(), self.play3(), self.status_2_button_secret_level()],
                                                         state="disabled")
        self.sidebar_button_11.grid(row=0, column=0, padx=8, pady=(8, 10))
        
        # кнопка игра 2 память
        self.sidebar_button_12 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e",
                                                         font=customtkinter.CTkFont(size=28), border_width=2, text=_("Память"), width=220, height=58,
                                                         command=lambda:[self.new_game_2(), self.clear_form(), self.hide_widget(),
                                                         self.play3(), self.status_2_button_secret_level(), self.entry.configure(state="disabled"),
                                                         self.hide_enter_numeric(), self.slider_button_15.configure(state="disabled")], state="disabled")
        self.sidebar_button_12.grid(row=1, column=0, padx=8, pady=10)
        
        # кнопка игра 3 концентрация
        self.sidebar_button_13 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", font=customtkinter.CTkFont(size=28), width=220, height=58,
                                                  text=_("Концентрация"), border_width=2,
                                        command= lambda:[self.new_game_3(), self.status_2_button_secret_level(), self.hide_widget()], state="disabled")
        self.sidebar_button_13.grid(row=2, column=0, padx=8, pady=10)
        
        # кнопка правил
        self.sidebar_button_16 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", font=customtkinter.CTkFont(size=28), width=220, height=58,
                                                         text=_("Правила"), border_width=2, command=lambda:[self.open_toplevel3(), self.play3()])
        self.sidebar_button_16.grid(row=6, column=0, padx=8, pady=10)
        
        # кнопка показа числа для игры память 
        self.sidebar_button_23 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e",
                                                         font=customtkinter.CTkFont(size=28), text=_("Показать"), border_width=2, width=220, height=58,
                                        command=lambda:[self.open_toplevel4(), self.play3(), self.sidebar_button_23.grid_forget(),
                                                        self.entry.configure(state="normal"), self.button_status_1(),
                                                        self.slider_button_15.configure(state="normal")], state="disabled")
        self.sidebar_button_23.grid(row=4, column=0, padx=8, pady=10)
        self.sidebar_button_23.grid_forget()

        # кнопка открытия игры концентрации
        self.sidebar_button_38 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", width=220, height=58,
                                                         font=customtkinter.CTkFont(size=28), text=_("Начать"), border_width=2,
                                        command=lambda:[self.open_toplevel12(), self.play3()], state="disabled")
        self.sidebar_button_38.grid(row=5, column=0, padx=8, pady=10, sticky="n")
        self.sidebar_button_38.grid_forget()
        
        # кнопка лабиринта
        self.sidebar_button_58 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", font=customtkinter.CTkFont(size=28), width=220, height=58,
                                                         text=_("Лабиринт"), border_width=5, command=lambda:[self.open_toplevel11(), self.play3()])
        self.sidebar_button_58.grid(row=3, column=0, padx=8, pady=10, sticky="n")

        # кнопка смены игры
        self.sidebar_button_62 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", font=customtkinter.CTkFont(size=28), width=220, height=58,
                           text=_("Сменить игру"), border_width=2, command=lambda:[self.reset_on_game_selection(), self.play10()], state="disabled")
        self.sidebar_button_62.grid(row=9, column=0, padx=8, pady=10, sticky="n")

        # кнопка начать заново  
        self.sidebar_button_55 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", font=customtkinter.CTkFont(size=28), width=220, height=58,
                    border_width=2, command=lambda:[self.new_game_reset(), self.play10()], text=_("Начать заново"), state="disabled")
        self.sidebar_button_55.grid_forget()
       
        # кнопка сброса  
        self.sidebar_button_14 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", font=customtkinter.CTkFont(size=28), width=220, height=58,
                    border_width=2, hover_color="#dc2525", command=lambda:[self.button_game_reset(), self.play10()], text=_("Сброс игры"))
        self.sidebar_button_14.grid(row=11, column=0, padx=8, pady=(10, 10), sticky="s")
        
        # кнопка выхода
        self.sidebar_button_15 = customtkinter.CTkButton(self.sidebar1_frame, fg_color="#3a689e", text=_("Выход"), font=customtkinter.CTkFont(size=28),
                                                         border_width=2, border_spacing=0, command=self.open_toplevel1, width=220, height=58)
        self.sidebar_button_15.grid(row=12, column=0, padx=8, pady=(10, 8), sticky="swe")
        self.toplevel_window = None

        # подпись прогресса
        self.logo_label = customtkinter.CTkLabel(self, text=_("Progress"), font=customtkinter.CTkFont(size=18, weight="bold"))
        
        self.logo_label.grid(row=5, column=5, columnspan=4, padx=(2, 0), pady=(8, 0), sticky="s")
        
        # прогресс прохождения уровня игры
        self.progressbar_4 = customtkinter.CTkProgressBar(self, fg_color="#696969", progress_color= "#cbad00",
                                                    width=8, height=220, border_width=1, border_color="#818181", orientation="vertical", mode="determinate")
        self.progressbar_4.grid(row=2, column=5, rowspan=4, padx=(8, 5), pady=(10, 25), sticky="nwes")
        self.progressbar_4.set(0)
        
        # прогресс ошибок
        self.progressbar_3 = customtkinter.CTkProgressBar(self, fg_color="#696969", progress_color="#dc2525",
                                                    width=8, height=220, border_width=1, border_color="#818181", orientation="vertical", mode="determinate")
        self.progressbar_3.grid(row=2, column=6, rowspan=4, padx=(5, 5), pady=(10, 25), sticky="nwes")
        self.progressbar_3.set(0)
        
        # прогресс бодрости
        self.progressbar_5 = customtkinter.CTkProgressBar(self, fg_color="#696969", progress_color="#24ccea",
                                                    width=8, height=220, border_width=1, border_color="#818181", orientation="vertical", mode="determinate")
        self.progressbar_5.grid(row=2, column=8, rowspan=4, padx=(5, 8), pady=(10, 25), sticky="nwes")
        self.progressbar_5.set(1)
        
        # прогресс выигрыша
        self.progressbar_6 = customtkinter.CTkProgressBar(self, fg_color="#696969", progress_color="#0aaa00",
                                                    width=8, height=220, border_width=1, border_color="#818181", orientation="vertical", mode="determinate")
        self.progressbar_6.grid(row=2, column=7, rowspan=4, padx=(5, 5), pady=(10, 25), sticky="nwes")
        self.progressbar_6.set(0)

        # поле при проигрыше
        self.sidebar4_frame = customtkinter.CTkFrame(self, width=150, corner_radius=5, border_width=2)
        
        self.canvas_10 = Canvas(self.sidebar4_frame, bg = "#3a689e", height = 280, width = 180, bd = 2)
        self.canvas_10.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(15, 2), pady=(28, 2))
        self.ava_10 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava4.1.png")
        self.ava_img_10 = self.canvas_10.create_image(2, 2, anchor=NW, image = self.ava_10)

        self.sidebar4_frame.grid(row=1, column=9, rowspan=2, padx=(2, 5), pady=(2, 5), sticky="nsew")

        # поле вкладок игроков
        my_font = customtkinter.CTkFont(size=15)
        
        self.tabview = customtkinter.CTkTabview(self, width=100, height =150, corner_radius=5,
                                                border_color="#454545", segmented_button_selected_color="#3a689e", border_width=2)
        self.tabview.grid(row=1, column=9, rowspan=2, padx=(2, 5), pady=(2, 2), sticky="new")
        
        self.tabview.add("     1     ")
        self.tabview.add("     2     ")
        self.tabview.add("     3     ")

        for button in self.tabview._segmented_button._buttons_dict.values():
            button.configure(width=50, height=28, font=my_font)
        
        # вкладка 1       
        self.canvas_1 = Canvas(self.tabview.tab("     1     "), bg = "#3a689e", height = 128, width = 155, bd = 12, relief=RAISED)
        self.canvas_1.grid(row=1, column=0, columnspan=1, rowspan=1, padx=(12, 12), pady=(2, 2))
        self.ava_1 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava1.2.png")
        self.ava_img_1 = self.canvas_1.create_image(12,80, anchor=W,  image = self.ava_1)
        self.canvas_1.tag_bind(self.ava_img_1, '<Button-1>', lambda event: [self.open_toplevel6(), self.play10()])
        
        self.logo_label_1_player_1 = customtkinter.CTkLabel(self.tabview.tab("     1     "), text= "Psiheiya",
                                                            font=customtkinter.CTkFont(size=22, weight="bold"))
        self.logo_label_1_player_1.grid(row=0, column=0, padx=(5, 5), pady=(0, 0), sticky="ew")

        self.button_28 = customtkinter.CTkButton(self.tabview.tab("     1     "), font=customtkinter.CTkFont(size=28), fg_color="#3a689e",
                                                 text_color_disabled="#383a3d", border_width=2, text=_("Выбрать"), width=80, height=28, state="normal",
                                                 command=self.button_24_player)
        self.button_28.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))

        self.logo_label_2_player_1 = customtkinter.CTkLabel(self.tabview.tab("     1     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_2_player_1.grid(row=3, column=0, padx=(5, 0), pady=(0, 0))
        self.logo_label_2_player_1.configure(text=_("Интуиция = 0"))
        self.logo_label_2_player_1.grid_forget()

        self.logo_label_3_player_1 = customtkinter.CTkLabel(self.tabview.tab("     1     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_3_player_1.grid(row=4, column=0, padx=(5, 0), pady=(0, 0))
        self.logo_label_3_player_1.configure(text=_("Память = 0"))
        self.logo_label_3_player_1.grid_forget()

        self.logo_label_4_player_1 = customtkinter.CTkLabel(self.tabview.tab("     1     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_4_player_1.grid(row=5, column=0, padx=(5, 0), pady=(0, 5))
        self.logo_label_4_player_1.configure(text=_("Концентрация = 0"))
        self.logo_label_4_player_1.grid_forget()
        
        # вкладка 2        
        self.canvas_2 = Canvas(self.tabview.tab("     2     "), bg = "#3a689e", height = 128, width = 155, bd = 12, relief=RAISED)
        self.canvas_2.grid(row=1, column=0, rowspan=1, padx=(12, 12), pady=(2, 2), sticky="nsew")
        self.ava_2 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava2.2.png")
        self.ava_img_2 = self.canvas_2.create_image(12,80, anchor=W,  image = self.ava_2)
        self.canvas_2.tag_bind(self.ava_img_2, '<Button-1>', lambda event: [self.open_toplevel7(), self.play10()])
        
        self.logo_label_1_player_2 = customtkinter.CTkLabel(self.tabview.tab("     2     "), text="Golem", font=customtkinter.CTkFont(size=22, weight="bold"))
        self.logo_label_1_player_2.grid(row=0, column=0, padx=(20, 20), pady=(0, 0), sticky="sn")

        self.button_29 = customtkinter.CTkButton(self.tabview.tab("     2     "), font=customtkinter.CTkFont(size=28),
                                                        fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=2, text=_("Выбрать"), width=80, height=28, state="normal", command=self.button_32_player)
        self.button_29.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))

        self.logo_label_2_player_2 = customtkinter.CTkLabel(self.tabview.tab("     2     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_2_player_2.grid(row=3, column=0, padx=(5, 0), pady=(0, 0))
        self.logo_label_2_player_2.configure(text=_("Интуиция = 0"))
        self.logo_label_2_player_2.grid_forget()

        self.logo_label_3_player_2 = customtkinter.CTkLabel(self.tabview.tab("     2     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_3_player_2.grid(row=4, column=0, padx=(5, 0), pady=(0, 0))
        self.logo_label_3_player_2.configure(text=_("Память = 0"))
        self.logo_label_3_player_2.grid_forget()

        self.logo_label_4_player_2 = customtkinter.CTkLabel(self.tabview.tab("     2     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_4_player_2.grid(row=5, column=0, padx=(5, 0), pady=(0, 5))
        self.logo_label_4_player_2.configure(text=_("Концентрация = 0"))
        self.logo_label_4_player_2.grid_forget()

        # вкладка 3
        self.canvas_3 = Canvas(self.tabview.tab("     3     "), bg = "#3a689e", height = 128, width = 155, bd = 12, relief=RAISED)
        self.canvas_3.grid(row=1, column=0, rowspan=1, padx=(12, 12), pady=(2, 2), sticky="nsew")
        self.ava_3 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava3.2.png")
        self.ava_img_3 = self.canvas_3.create_image(12,80, anchor=W,  image = self.ava_3)
        self.canvas_3.tag_bind(self.ava_img_3, '<Button-1>', lambda event: [self.open_toplevel8(), self.play10()])

        self.logo_label_1_player_3 = customtkinter.CTkLabel(self.tabview.tab("     3     "), text="Expand", font=customtkinter.CTkFont(size=22, weight="bold"))
        self.logo_label_1_player_3.grid(row=0, column=0, padx=(20, 20), pady=(0, 0), sticky="sn")

        self.button_30 = customtkinter.CTkButton(self.tabview.tab("     3     "), font=customtkinter.CTkFont(size=28),
                                                        fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=2, text=_("Выбрать"), width=80, height=28, state="normal", command=self.button_33_player)
        self.button_30.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))

        self.logo_label_2_player_3 = customtkinter.CTkLabel(self.tabview.tab("     3     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_2_player_3.grid(row=3, column=0, padx=(5, 0), pady=(0, 0))
        self.logo_label_2_player_3.configure(text=_("Интуиция = 0"))
        self.logo_label_2_player_3.grid_forget()

        self.logo_label_3_player_3 = customtkinter.CTkLabel(self.tabview.tab("     3     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_3_player_3.grid(row=4, column=0, padx=(5, 0), pady=(0, 0))
        self.logo_label_3_player_3.configure(text=_("Память = 0"))
        self.logo_label_3_player_3.grid_forget()
        
        self.logo_label_4_player_3 = customtkinter.CTkLabel(self.tabview.tab("     3     "), font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label_4_player_3.grid(row=5, column=0, padx=(5, 0), pady=(0, 5))
        self.logo_label_4_player_3.configure(text=_("Концентрация = 0"))
        self.logo_label_4_player_3.grid_forget()

        # правая боковая панель 2
        self.sidebar3_frame = customtkinter.CTkFrame(self, width=150, corner_radius=5, border_width=2)
        self.sidebar3_frame.grid(row=3, column=9, rowspan=5, padx=(2, 5), sticky="nsew")
        
        # кнопки правой боковой панели 2
        self.sidebar_button_1 = customtkinter.CTkButton(self.sidebar3_frame, font=customtkinter.CTkFont(size=38),
                                                        fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="1", width=58, height=58, state="disabled", command=self.button_1)
        self.sidebar_button_1.grid(row=1, column=0, padx=(5, 5), pady=(8, 5))
        
        self.sidebar_button_2 = customtkinter.CTkButton(self.sidebar3_frame, font=customtkinter.CTkFont(size=38),
                                                        fg_color="#3a689e", text_color_disabled="#383a3d", border_width=5, text="2",
                                                        width=58, height=58, state="disabled", command=self.button_2)
        self.sidebar_button_2.grid(row=1, column=1, padx=5, pady=(8, 5))
        
        self.sidebar_button_3 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="3", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_3)
        self.sidebar_button_3.grid(row=1, column=2, padx=(5, 5), pady=(8, 5))
        
        self.sidebar_button_4 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="4", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_4)
        self.sidebar_button_4.grid(row=2, column=0, padx=(5, 5), pady=5)
        
        self.sidebar_button_5 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="5", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_5)
        self.sidebar_button_5.grid(row=2, column=1, padx=5, pady=5)
        
        self.sidebar_button_6 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="6", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_6)
        self.sidebar_button_6.grid(row=2, column=2, padx=(5, 5), pady=5)
        
        self.sidebar_button_7 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="7", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_7)
        self.sidebar_button_7.grid(row=3, column=0, padx=(5, 5), pady=(5, 5))

        self.sidebar_button_8 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="8", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_8)
        self.sidebar_button_8.grid(row=3, column=1, padx=5, pady=(5, 5))

        self.sidebar_button_9 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="9", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_9)
        self.sidebar_button_9.grid(row=3, column=2, padx=(5, 5), pady=(5, 5))

        self.sidebar_button_0 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                        border_width=5, text="0", font=customtkinter.CTkFont(size=38),
                                                        width=58, height=58, state="disabled", command=self.button_0)
        self.sidebar_button_0.grid(row=4, column=2, padx=(5, 5), pady=(5, 8))
        
        self.sidebar_button_10 = customtkinter.CTkButton(self.sidebar3_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                                         state="disabled", border_width=2, text=_("Отмена"), font=customtkinter.CTkFont(size=32),
                                                         width=125, height=58, command=self.backspace)
        self.sidebar_button_10.grid(row=4, column=0, columnspan=2, padx=(5, 5), pady=(5, 8), sticky="ws")
        
        # нижняя панель
        self.slider4_progressbar_frame = customtkinter.CTkFrame(self, corner_radius=5, border_color="#454545", border_width=2)
        self.slider4_progressbar_frame.grid(row=6, column=1, columnspan=8, padx=(2, 2), pady=(2, 5), sticky="nsew")
        self.slider4_progressbar_frame.grid_columnconfigure((0,1,2,3,4,5), weight=1)
        self.slider4_progressbar_frame.grid_rowconfigure(3, weight=0)
        self.slider4_progressbar_frame.grid_rowconfigure(2, weight=0)
        
        # кнопка ENTER
        self.slider_button_15 = customtkinter.CTkButton(self.slider4_progressbar_frame, text=_("Enter"), fg_color="#3a689e",
                              text_color_disabled="#383a3d", border_width=2, font=customtkinter.CTkFont(size=58, weight="bold"), height=80, width=250,
                              command=lambda:[self.countdown(), self.level_score(), self.game_selection(), self.clear_form()], state="disabled")
        self.slider_button_15.grid(row=0, column=0, columnspan=6, padx=(80, 80), pady=(5, 5), sticky="we")

        # нижняя панель 2
        self.slider4_progressbar_2_frame = customtkinter.CTkFrame(self.slider4_progressbar_frame, corner_radius=5, border_color="#454545", border_width=2)
        self.slider4_progressbar_2_frame.grid(row=1, rowspan=1, column=0, columnspan=6, padx=(5, 5), pady=(2, 0), sticky="sew")
        self.slider4_progressbar_2_frame.grid_columnconfigure((0,1,2,3,4,5), weight=1)
        self.slider4_progressbar_2_frame.grid_rowconfigure(1, weight=0)
        self.slider4_progressbar_2_frame.grid_rowconfigure(2, weight=0)
               
        # слайдер выбора сложности игры        
        self.amount_slider_1 = customtkinter.CTkSlider(self.slider4_progressbar_2_frame, from_=1, to=6, number_of_steps=5,
                                                       width=18, height=28, state="normal")
        self.amount_slider_1.grid(row=1, column=0, columnspan=6, padx=(58, 58), pady=(5, 5), sticky="we")
        self.amount_slider_1.configure(button_color="#dc2525", fg_color="#adb2b8", progress_color="#adb2b8", border_width=8, border_color="#2d5a8c")
        self.amount_slider_1.configure(command=self.level_1_game)
        self.amount_slider_1.set(1)
        
        # кнопка выбора сложности игры 1
        self.slider_button_17 = customtkinter.CTkButton(self.slider4_progressbar_2_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                      font=customtkinter.CTkFont(size=20), text="1",width=25, height=28, border_width=2, command=self.slider_level_1)
        self.slider_button_17.grid(row=0, column=0, padx=(15, 8), pady=(8, 2), sticky="wesn")

        # кнопка выбора сложности игры 2
        self.slider_button_18 = customtkinter.CTkButton(self.slider4_progressbar_2_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                     font=customtkinter.CTkFont(size=20), text="2",width=25, height=28, border_width=2, command=self.slider_level_2)
        self.slider_button_18.grid(row=0, column=1, padx=(8, 8), pady=(8, 2), sticky="wesn")

        # кнопка выбора сложности игры 3
        self.slider_button_19 = customtkinter.CTkButton(self.slider4_progressbar_2_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                     font=customtkinter.CTkFont(size=20), text="3",width=25, height=28, border_width=2, command=self.slider_level_3)
        self.slider_button_19.grid(row=0, column=2, padx=(8, 8), pady=(8, 2), sticky="wesn")

        # кнопка выбора сложности игры 4
        self.slider_button_20 = customtkinter.CTkButton(self.slider4_progressbar_2_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                     font=customtkinter.CTkFont(size=20), text="4",width=25, height=28, border_width=2, command=self.slider_level_4)
        self.slider_button_20.grid(row=0, column=3, padx=(8, 8), pady=(8, 2), sticky="wesn")

        # кнопка выбора сложности игры 5
        self.slider_button_21 = customtkinter.CTkButton(self.slider4_progressbar_2_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                     font=customtkinter.CTkFont(size=20), text="5",width=25, height=28, border_width=2, command=self.slider_level_5)
        self.slider_button_21.grid(row=0, column=4, padx=(8, 8), pady=(8, 2), sticky="wesn")

        # кнопка выбора сложности игры 6
        self.slider_button_22 = customtkinter.CTkButton(self.slider4_progressbar_2_frame, fg_color="#3a689e", text_color_disabled="#383a3d",
                                     font=customtkinter.CTkFont(size=20), text="6",width=25, height=28, border_width=2, command=self.slider_level_6)
        self.slider_button_22.grid(row=0, column=5, padx=(8, 15), pady=(8, 2), sticky="wesn")

        # подпись выбора цвета
        self.logo_label = customtkinter.CTkLabel(self, text= "R__G__B", font=customtkinter.CTkFont(size=15, weight="bold"))
        self.logo_label.grid(row=5, column=1, columnspan=3, padx=(5, 0), pady=(2, 0), sticky="ws")
        
        # прогрессбар футера 1
        self.progressbar_1 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_1.grid(row=8, column=0, columnspan=10, padx=(20, 20), pady=(2, 2), sticky="ew")
        self.progressbar_1.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_1.start()
        
        # футер
        self.logo_label = customtkinter.CTkLabel(self, height=15,
             text=_("""© 2023 Wizards & Programmers Club. Created by magic and with the support of " some mother " production. Contact - mail: WPClub@proton.me"""),
                                                 font=customtkinter.CTkFont(size=12, weight="bold"))
        self.logo_label.grid(row=9, column=0, columnspan=10, padx=(8, 8), pady=(2, 2), sticky="n")

        # прогрессбар футера 2
        self.progressbar_2 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_2.grid(row=10, column=0, columnspan=10, padx=(20, 20), pady=(2, 2), sticky="nswe")
        self.progressbar_2.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#3a689e")
        self.progressbar_2.start()

        # прогрессбар футера 3
        self.progressbar_21 = customtkinter.CTkProgressBar(self, height=2)
        self.progressbar_21.grid(row=11, column=0, columnspan=10, padx=(20, 20), pady=(2, 2), sticky="nswe")
        self.progressbar_21.configure(mode="indeterminnate", indeterminate_speed=0.05, progress_color="#24ccea")
        self.progressbar_21.set(0)

        # скрыть кнопки при запуске программы и запуск заставки
        self.start_hide_widget()

    # скрытые кнопки при запуске программы
    def start_hide_widget(self):
        print("start_hide_widget")
        self.hide_widget()
        self.logo_label_2_player_1.grid_forget()
        self.logo_label_3_player_1.grid_forget()
        self.logo_label_4_player_1.grid_forget()
        self.logo_label_2_player_2.grid_forget()
        self.logo_label_3_player_2.grid_forget()
        self.logo_label_4_player_2.grid_forget()
        self.logo_label_2_player_3.grid_forget()
        self.logo_label_3_player_3.grid_forget()
        self.logo_label_4_player_3.grid_forget()
        self.slider4_progressbar_2_frame.grid_forget()
        self.sidebar_button_14.grid_forget()
        self.sidebar_button_58.grid_forget()
        self.sidebar_button_62.grid_forget()
        self.sidebar_button_62.configure(state='disabled')
        self.sidebar4_frame.grid_forget()
        
    # значения языка при запуске для перевода файлов
    def s_translater_txt(self):
        global lang_txt
        lang_txt = [0]
        self.open_toplevel15()
        print('lang_txt1 = ' + str(lang_txt))
        
    # значения при выборе языка для перевода файлов
    def translater_txt_zh(self):
        global lang_txt
        lang_txt = [1]
        print('lang_txt1 = ' + str(lang_txt))
    def translater_txt_ru(self):
        global lang_txt
        lang_txt = [0]
        print('lang_txt0 = ' + str(lang_txt))
    def translater_txt_en(self):
        global lang_txt
        lang_txt = [2]
        print('lang_txt2 = ' + str(lang_txt))
    def translater_txt_es(self):
        global lang_txt
        lang_txt = [3]
        print('lang_txt3 = ' + str(lang_txt))
    def translater_txt_pt(self):
        global lang_txt
        lang_txt = [4]
        print('lang_txt4 = ' + str(lang_txt))
    def translater_txt_fr(self):
        global lang_txt
        lang_txt = [5]
        print('lang_txt5 = ' + str(lang_txt))
    def translater_txt_de(self):
        global lang_txt
        lang_txt = [6]
        print('lang_txt6 = ' + str(lang_txt))
        
    # вывод случайной строки из файла
    def loadMylist(self):
        global Max
        global Mylist
        print('lang_txt3 = ' + str(lang_txt))
        Nr = 0
        try:
                print("Opening file...")
                if lang_txt == [0]:
                    print("lang_txt == [0]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text/diagnose.txt", "r")
                if lang_txt == [1]:
                    print("lang_txt == [1]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text_zh/诊断.txt", "r")
                if lang_txt == [2]:
                    print("lang_txt == [2]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text_en/diagnose.txt", "r")
                if lang_txt == [3]:
                    print("lang_txt == [3]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text_es/diagnose.txt", "r")
                if lang_txt == [4]:
                    print("lang_txt == [4]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text_pt/diagnose.txt", "r")
                if lang_txt == [5]:
                    print("lang_txt == [5]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text_fr/diagnose.txt", "r")
                if lang_txt == [6]:
                    print("lang_txt == [6]")
                    File = open("/home/lord/MEGAsync/books/python/Oracl/text_de/diagnose.txt", "r")
                    
                Mylist = []
                for String in File:
                        Mylist.append(String.rstrip())
                        Nr += 1
                Max = Nr - 1
                File.close()
        except :
                Mylist.append(_("Что-то не так с файлом "))

    # игрок 1
    def button_24_player(self):
        print("button_24_player")
        global select_player
        global stat_player_1_game_1
        global stat_player_1_game_2
        global stat_player_1_game_3
        global hero_name
        self. play6()
        select_player = 1
        hero_name = " Psiheiya "
        self.button_28.grid_forget()
        self.clear_form()
        self.ava_1 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava1.1.png")
        self.ava_img_1 = self.canvas_1.create_image(12,80, anchor=W,  image = self.ava_1)
        self.canvas_1.tag_bind(self.ava_img_1, '<Button-1>', lambda event: [self.open_toplevel6(), self.play10()])
        self.ava_2 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava2.2.png")
        self.ava_img_2 = self.canvas_2.create_image(12,80, anchor=W,  image = self.ava_2)
        self.canvas_2.tag_bind(self.ava_img_2, '<Button-1>', lambda event: [self.open_toplevel7(), self.play10()])
        self.ava_3 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava3.2.png")
        self.ava_img_3 = self.canvas_3.create_image(12,80, anchor=W,  image = self.ava_3)
        self.canvas_3.tag_bind(self.ava_img_3, '<Button-1>', lambda event: [self.open_toplevel8(), self.play10()])
        self.slider4_progressbar_2_frame.grid(row=1, rowspan=1, column=0, columnspan=6, padx=(8, 8), pady=(2, 2), sticky="sew")   
        self.logo_label_2_player_1.grid(row=3, column=0, padx=(5, 0), pady=(0, 0), sticky="w")
        self.logo_label_3_player_1.grid(row=4, column=0, padx=(5, 0), pady=(0, 0), sticky="w")
        self.logo_label_4_player_1.grid(row=5, column=0, padx=(5, 0), pady=(0, 5), sticky="w")
        self.logo_label_2_player_2.grid_forget()
        self.logo_label_3_player_2.grid_forget()
        self.logo_label_4_player_2.grid_forget()
        self.logo_label_2_player_3.grid_forget()
        self.logo_label_3_player_3.grid_forget()
        self.logo_label_4_player_3.grid_forget()        
        self.button_29.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))        
        self.button_30.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
            file_stat_player_1_game_1 = f.read()
        self.logo_label_2_player_1.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_1_game_1) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
            file_stat_player_1_game_2 = f.read()
        self.logo_label_3_player_1.configure(text=_("Память = ") + str('%.4s' % file_stat_player_1_game_2) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
            file_stat_player_1_game_3 = f.read()
        self.logo_label_4_player_1.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_1_game_3) + "%")
        
        # открытие кнопки расчет количества ходов для лабиринта
        stat_player_1_game_1 = [0]    
        stat_player_1_game_1[0] = float(file_stat_player_1_game_1)
        stat_player_1_game_2 = [0]    
        stat_player_1_game_2[0] = float(file_stat_player_1_game_2)
        stat_player_1_game_3 = [0]    
        stat_player_1_game_3[0] = float(file_stat_player_1_game_3)        
        if stat_player_1_game_1[0] >= 50 and stat_player_1_game_2[0] >= 25 and stat_player_1_game_3[0] >= 25 and game_selection == 0:
            self.status_1_button_secret_level()
        else:
            self.status_2_button_secret_level()
        steps_for_maze = stat_player_1_game_1[0] * 2 + stat_player_1_game_2[0] * 2 + stat_player_1_game_3[0] * 2
        with open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer1.txt", 'r') as f:
            file_step_1 = f.read()                        
        list_steps_for_maze_1 = str(steps_for_maze)
        file_step_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer1.txt", 'w')            
        for element in list_steps_for_maze_1:
            file_step_1.write(element)
        file_step_1.close()        
        self.logo_info_status4.configure(text = '[' + str(int(move_geme_progress[0])) + ']')
        self.reset_on_player_selection()
        self.clear_form()        
        
    # игрок 2
    def button_32_player(self):
        print("button_32_player")
        global select_player
        global stat_player_2_game_1
        global stat_player_2_game_2
        global stat_player_2_game_3
        global hero_name
        self. play6()
        select_player = 2
        hero_name = " Golem "
        self.button_29.grid_forget()
        self.clear_form()        
        self.ava_1 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava1.2.png")
        self.ava_img_1 = self.canvas_1.create_image(12,80, anchor=W,  image = self.ava_1)
        self.canvas_1.tag_bind(self.ava_img_1, '<Button-1>', lambda event: [self.open_toplevel6(), self.play10()])
        self.ava_2 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava2.1.png")
        self.ava_img_2 = self.canvas_2.create_image(12,80, anchor=W,  image = self.ava_2)
        self.canvas_2.tag_bind(self.ava_img_2, '<Button-1>', lambda event: [self.open_toplevel7(), self.play10()])
        self.ava_3 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava3.2.png")
        self.ava_img_3 = self.canvas_3.create_image(12,80, anchor=W,  image = self.ava_3)
        self.canvas_3.tag_bind(self.ava_img_3, '<Button-1>', lambda event: [self.open_toplevel8(), self.play10()])
        self.slider4_progressbar_2_frame.grid(row=1, rowspan=1, column=0, columnspan=6, padx=(8, 8), pady=(2, 2), sticky="sew")
        self.logo_label_2_player_2.grid(row=3, column=0, padx=(5, 0), pady=(0, 0), sticky="w")
        self.logo_label_3_player_2.grid(row=4, column=0, padx=(5, 0), pady=(0, 5), sticky="w")
        self.logo_label_4_player_2.grid(row=5, column=0, padx=(5, 0), pady=(0, 5), sticky="w")        
        self.logo_label_2_player_1.grid_forget()
        self.logo_label_3_player_1.grid_forget()
        self.logo_label_4_player_1.grid_forget()
        self.logo_label_2_player_3.grid_forget()
        self.logo_label_3_player_3.grid_forget()
        self.logo_label_4_player_3.grid_forget()        
        self.button_28.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))
        self.button_30.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
            file_stat_player_2_game_1 = f.read()
        self.logo_label_2_player_2.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_2_game_1) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
            file_stat_player_2_game_2 = f.read()
        self.logo_label_3_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_2) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
            file_stat_player_2_game_3 = f.read()
        self.logo_label_4_player_2.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_2_game_3) + "%")

        # открытие кнопки расчет количества ходов для лабиринта
        stat_player_2_game_1 = [0]    
        stat_player_2_game_1[0] = float(file_stat_player_2_game_1)
        stat_player_2_game_2 = [0]    
        stat_player_2_game_2[0] = float(file_stat_player_2_game_2)
        stat_player_2_game_3 = [0]    
        stat_player_2_game_3[0] = float(file_stat_player_2_game_3)        
        if stat_player_2_game_1[0] >= 25 and stat_player_2_game_2[0] >= 50 and stat_player_2_game_3[0] >= 25 and game_selection == 0:
            self.status_1_button_secret_level()
        else:
            self.status_2_button_secret_level()
        steps_for_maze = stat_player_2_game_1[0] * 2.5 + stat_player_2_game_2[0] * 2.5 + stat_player_2_game_3[0] * 2.5
        with open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer2.txt", 'r') as f:
            file_step_2 = f.read()                        
        list_steps_for_maze_2 = str(steps_for_maze)
        file_step_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer2.txt", 'w')            
        for element in list_steps_for_maze_2:
            file_step_2.write(element)
        file_step_2.close()
        self.logo_info_status4.configure(text = '[' + str(int(move_geme_progress[0])) + ']')
        self.reset_on_player_selection()
        self.clear_form()

    # игрок 3
    def button_33_player(self):
        print("button_33_player")
        global select_player
        global stat_player_3_game_1
        global stat_player_3_game_2
        global stat_player_3_game_3
        global hero_name
        self. play6()
        select_player = 3
        hero_name = " Expand "
        self.button_30.grid_forget()
        self.clear_form()        
        self.ava_1 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava1.2.png")
        self.ava_img_1 = self.canvas_1.create_image(12,80, anchor=W,  image = self.ava_1)
        self.canvas_1.tag_bind(self.ava_img_1, '<Button-1>', lambda event: [self.open_toplevel6(), self.play10()])
        self.ava_2 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava2.2.png")
        self.ava_img_2 = self.canvas_2.create_image(12,80, anchor=W,  image = self.ava_2)
        self.canvas_2.tag_bind(self.ava_img_2, '<Button-1>', lambda event: [self.open_toplevel7(), self.play10()])
        self.ava_3 = PhotoImage(file="/home/lord/MEGAsync/books/python/Oracl/image/Ava3.1.png")
        self.ava_img_3 = self.canvas_3.create_image(12,80, anchor=W,  image = self.ava_3)
        self.canvas_3.tag_bind(self.ava_img_3, '<Button-1>', lambda event: [self.open_toplevel8(), self.play10()])        
        self.slider4_progressbar_2_frame.grid(row=1, rowspan=1, column=0, columnspan=6, padx=(8, 8), pady=(2, 2), sticky="sew")
        self.logo_label_2_player_3.grid(row=3, column=0, padx=(5, 0), pady=(0, 0), sticky="w")
        self.logo_label_3_player_3.grid(row=4, column=0, padx=(5, 0), pady=(0, 5), sticky="w")
        self.logo_label_4_player_3.grid(row=5, column=0, padx=(5, 0), pady=(0, 5), sticky="w")        
        self.logo_label_2_player_1.grid_forget()
        self.logo_label_3_player_1.grid_forget()
        self.logo_label_4_player_1.grid_forget()
        self.logo_label_2_player_2.grid_forget()
        self.logo_label_3_player_2.grid_forget()
        self.logo_label_4_player_2.grid_forget()        
        self.button_28.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))
        self.button_29.grid(row=2, column=0, padx=(15, 5), pady=(2, 2))
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
            file_stat_player_3_game_1 = f.read()
        self.logo_label_2_player_3.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_3_game_1) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
            file_stat_player_3_game_2 = f.read()
        self.logo_label_3_player_3.configure(text=_("Память = ") + str('%.4s' % file_stat_player_3_game_2) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
            file_stat_player_3_game_3 = f.read()
        self.logo_label_4_player_3.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_3_game_3) + "%")

        # открытие кнопки расчет количества ходов для лабиринта
        stat_player_3_game_1 = [0]    
        stat_player_3_game_1[0] = float(file_stat_player_3_game_1)
        stat_player_3_game_2 = [0]    
        stat_player_3_game_2[0] = float(file_stat_player_3_game_2)
        stat_player_3_game_3 = [0]    
        stat_player_3_game_3[0] = float(file_stat_player_3_game_3)        
        if stat_player_3_game_1[0] >= 25 and stat_player_3_game_2[0] >= 25 and stat_player_3_game_3[0] >= 80 and game_selection == 0:
            self.status_1_button_secret_level()
        else:
            self.status_2_button_secret_level()

        steps_for_maze = stat_player_3_game_1[0] * 3.3 + stat_player_3_game_2[0] * 3.3 + stat_player_3_game_3[0] * 3.3

        with open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer3.txt", 'r') as f:
            file_step_3 = f.read()                        
        list_steps_for_maze_3 = str(steps_for_maze)
        file_step_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/stepsplayer3.txt", 'w')            
        for element in list_steps_for_maze_3:
            file_step_3.write(element)
        file_step_3.close()
        self.logo_info_status4.configure(text = '[' + str(int(move_geme_progress[0])) + ']')
        self.reset_on_player_selection()
        self.clear_form()

    # игроки запись в файл
    def select_player(self):
        print("select_player")
        global mass_1, mass_2, mass_3, mass_4
        if select_player == 1 and game_selection == 1:            
            bonus_player_1_game_1 = 10000           # коефициент набора процентов игрока
            mass_1 = 0.2                            # прохождение уровня
            mass_2 = 0.071428571                    # ошибки
            mass_3 = 0.012                          # бодрость
            mass_4 = 0.033333333                    # прохождение игры            
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                file_stat_player_1_game_1 = f.read()                
            stat_player_1_game_1 = [0]    
            stat_player_1_game_1[0] = float(file_stat_player_1_game_1)            
            stat_player_1_game_1[0] += a[0]/bonus_player_1_game_1            
            list_stat_player_1_game_1 = str(stat_player_1_game_1[0])
            file_stat_player_1_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'w')            
            for element in list_stat_player_1_game_1:
                 file_stat_player_1_game_1.write(element)
            file_stat_player_1_game_1.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
                file_stat_player_1_game_1 = f.read()
            self.logo_label_2_player_1.configure(text=_("Интуиция = ") + str(file_stat_player_1_game_1[0:4]) + "%")
        if select_player == 1 and game_selection == 2:
            bonus_player_1_game_2 = 10000           # коефициент набора процентов игрока
            mass_1 = 0.2                            # прохождение уровня
            mass_2 = 0.333333333                    # ошибки
            mass_3 = 0.012                          # бодрость
            mass_4 = 0.033333333                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                file_stat_player_1_game_2 = f.read()                
            stat_player_1_game_2 = [0]    
            stat_player_1_game_2[0] = float(file_stat_player_1_game_2)            
            stat_player_1_game_2[0] += a[0]/bonus_player_1_game_2            
            list_stat_player_1_game_2 = str(stat_player_1_game_2[0])
            file_stat_player_1_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'w')            
            for element in list_stat_player_1_game_2:
                 file_stat_player_1_game_2.write(element)
            file_stat_player_1_game_2.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
                file_stat_player_1_game_2 = f.read()
            self.logo_label_3_player_1.configure(text=_("Память = ") + str('%.4s' % file_stat_player_1_game_2) + "%")
        if select_player == 1 and game_selection == 3:
            bonus_player_1_game_3 = 10000           # коефициент набора процентов игрока
            mass_1 = 1                              # прохождение уровня
            mass_2 = 0.1                            # ошибки
            mass_3 = 0.012                          # бодрость
            mass_4 = 0.166666667                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                file_stat_player_1_game_3 = f.read()                
            stat_player_1_game_3 = [0]    
            stat_player_1_game_3[0] = float(file_stat_player_1_game_3)            
            stat_player_1_game_3[0] += a[0]/bonus_player_1_game_3            
            list_stat_player_1_game_3 = str(stat_player_1_game_3[0])
            file_stat_player_1_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'w')            
            for element in list_stat_player_1_game_3:
                 file_stat_player_1_game_3.write(element)
            file_stat_player_1_game_3.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
                file_stat_player_1_game_3 = f.read()
            self.logo_label_4_player_1.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_1_game_3) + "%")
        if select_player == 2 and game_selection == 1:
            bonus_player_2_game_1 = 10000           # коефициент набора процентов игрока
            mass_1 = 0.2                            # прохождение уровня
            mass_2 = 0.071428571                    # ошибки
            mass_3 = 0.008                          # бодрость
            mass_4 = 0.033333333                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                file_stat_player_2_game_1 = f.read()                
            stat_player_2_game_1 = [0]    
            stat_player_2_game_1[0] = float(file_stat_player_2_game_1)            
            stat_player_2_game_1[0] += a[0]/bonus_player_2_game_1            
            list_stat_player_2_game_1 = str(stat_player_2_game_1[0])
            file_stat_player_2_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'w')            
            for element in list_stat_player_2_game_1:
                 file_stat_player_2_game_1.write(element)
            file_stat_player_2_game_1.close()            
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
                file_stat_player_2_game_1 = f.read()
            self.logo_label_2_player_2.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_2_game_1) + "%")
        if select_player == 2 and game_selection == 2:            
            bonus_player_2_game_2 = 10000           # коефициент набора процентов игрока
            mass_1 = 0.2                            # прохождение уровня
            mass_2 = 0.333333333                    # ошибки
            mass_3 = 0.008                          # бодрость
            mass_4 = 0.033333333                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                file_stat_player_2_game_2 = f.read()                
            stat_player_2_game_2 = [0]    
            stat_player_2_game_2[0] = float(file_stat_player_2_game_2)            
            stat_player_2_game_2[0] += a[0]/bonus_player_2_game_2            
            list_stat_player_2_game_2 = str(stat_player_2_game_2[0])
            file_stat_player_2_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'w')            
            for element in list_stat_player_2_game_2:
                 file_stat_player_2_game_2.write(element)
            file_stat_player_2_game_2.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
                file_stat_player_2_game_2 = f.read()
            self.logo_label_3_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_2) + "%")            
        if select_player == 2 and game_selection == 3:
            bonus_player_2_game_3 = 10000           # коефициент набора процентов игрока
            mass_1 = 1                              # прохождение уровня
            mass_2 = 0.1                            # ошибки
            mass_3 = 0.008                          # бодрость
            mass_4 = 0.166666667                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                file_stat_player_2_game_3 = f.read()                
            stat_player_2_game_3 = [0]    
            stat_player_2_game_3[0] = float(file_stat_player_2_game_3)            
            stat_player_2_game_3[0] += a[0]/bonus_player_2_game_3            
            list_stat_player_2_game_3 = str(stat_player_2_game_3[0])
            file_stat_player_2_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'w')            
            for element in list_stat_player_2_game_3:
                 file_stat_player_2_game_3.write(element)
            file_stat_player_2_game_3.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
                file_stat_player_2_game_3 = f.read()
            self.logo_label_4_player_2.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_2_game_3) + "%")
        if select_player == 3 and game_selection == 1:
            bonus_player_3_game_1 = 10000          # коефициент набора процентов игрока
            mass_1 = 0.2                           # прохождение уровня
            mass_2 = 0.071428571                   # ошибки
            mass_3 = 0.01                          # обратный отсчет
            mass_4 = 0.033333333                   # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
                file_stat_player_3_game_1 = f.read()                
            stat_player_3_game_1 = [0]    
            stat_player_3_game_1[0] = float(file_stat_player_3_game_1)            
            stat_player_3_game_1[0] += a[0]/bonus_player_3_game_1            
            list_stat_player_3_game_1 = str(stat_player_3_game_1[0])
            file_stat_player_3_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'w')            
            for element in list_stat_player_3_game_1:
                 file_stat_player_3_game_1.write(element)
            file_stat_player_3_game_1.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
                file_stat_player_3_game_1 = f.read()
            self.logo_label_2_player_3.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_3_game_1) + "%")            
        if select_player == 3 and game_selection == 2:            
            bonus_player_3_game_2 = 10000           # коефициент набора процентов игрока
            mass_1 = 0.2                            # прохождение уровня
            mass_2 = 0.333333333                    # ошибки
            mass_3 = 0.01                           # обратный отсчет
            mass_4 = 0.033333333                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
                file_stat_player_3_game_2 = f.read()                
            stat_player_3_game_2 = [0]    
            stat_player_3_game_2[0] = float(file_stat_player_3_game_2)            
            stat_player_3_game_2[0] += a[0]/bonus_player_3_game_2            
            list_stat_player_3_game_2 = str(stat_player_3_game_2[0])
            file_stat_player_3_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'w')            
            for element in list_stat_player_3_game_2:
                 file_stat_player_3_game_2.write(element)
            file_stat_player_3_game_2.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
                file_stat_player_3_game_2 = f.read()
            self.logo_label_3_player_3.configure(text=_("Память = ") + str('%.4s' % file_stat_player_3_game_2) + "%")            
        if select_player == 3 and game_selection == 3:
            bonus_player_3_game_3 = 10000           # коефициент набора процентов игрока
            mass_1 = 1                              # прохождение уровня
            mass_2 = 0.1                            # ошибки
            mass_3 = 0.01                           # обратный отсчет
            mass_4 = 0.166666667                    # прохождение игры
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
                file_stat_player_3_game_3 = f.read()                
            stat_player_3_game_3 = [0]    
            stat_player_3_game_3[0] = float(file_stat_player_3_game_3)            
            stat_player_3_game_3[0] += a[0]/bonus_player_3_game_3            
            list_stat_player_3_game_3 = str(stat_player_3_game_3[0])
            file_stat_player_3_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'w')            
            for element in list_stat_player_3_game_3:
                 file_stat_player_3_game_3.write(element)
            file_stat_player_3_game_3.close()
            with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
                file_stat_player_3_game_3 = f.read()
            self.logo_label_4_player_3.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_3_game_3) + "%")

    def status_1_button_secret_level(self):
        print("status_1_button_secret_level")
        if game_selection != 1 or game_selection != 2 or game_selection != 3:
            self.sidebar_button_58.grid(row=3, column=0, padx=8, pady=10, sticky="n")
            self.sidebar_button_58.configure(state="normal")

    def status_2_button_secret_level(self):
        print("status_2_button_secret_level")
        self.sidebar_button_58.grid_forget()
        self.sidebar_button_58.configure(state="disabled")

    # статус кнопок при начале игры
    def button_status_1(self):
        print("button_status_1")
        self.slider_button_15.configure(state="normal")     
        self.sidebar_button_10.configure(state="normal")
        self.sidebar_button_1.configure(state="normal")
        self.sidebar_button_2.configure(state="normal")
        self.sidebar_button_3.configure(state="normal")
        self.sidebar_button_4.configure(state="normal")
        self.sidebar_button_5.configure(state="normal")
        self.sidebar_button_6.configure(state="normal")
        self.sidebar_button_7.configure(state="normal")
        self.sidebar_button_8.configure(state="normal")
        self.sidebar_button_9.configure(state="normal")
        self.sidebar_button_0.configure(state="normal")
        self.amount_slider_1.configure(state="disabled")
        self.slider_button_17.configure(state="disabled")
        self.slider_button_18.configure(state="disabled")
        self.slider_button_19.configure(state="disabled")
        self.slider_button_20.configure(state="disabled")
        self.slider_button_21.configure(state="disabled")
        self.slider_button_22.configure(state="disabled")
        self.entry.configure(state="normal")
        self.progressbar_3.set(0)
        
    # статус кнопок при завершении игры
    def button_status_2(self):
        print("button_status_2")
        self.hide_enter_numeric()
        self.slider_button_15.configure(state="disabled")
        self.sidebar_button_11.configure(state="disabled")
        self.amount_slider_1.configure(state="normal")
        self.slider_button_17.configure(state="normal")
        self.slider_button_18.configure(state="normal")
        self.slider_button_19.configure(state="normal")
        self.slider_button_20.configure(state="normal")
        self.slider_button_21.configure(state="normal")
        self.slider_button_22.configure(state="normal")
        self.entry.configure(state="disabled") 

   # скрытие числовых кнопок ввода
    def hide_enter_numeric(self):
        print("hide_enter_numeric")
        self.sidebar_button_10.configure(state="disabled")
        self.sidebar_button_1.configure(state="disabled")
        self.sidebar_button_2.configure(state="disabled")
        self.sidebar_button_3.configure(state="disabled")
        self.sidebar_button_4.configure(state="disabled")
        self.sidebar_button_5.configure(state="disabled")
        self.sidebar_button_6.configure(state="disabled")
        self.sidebar_button_7.configure(state="disabled")
        self.sidebar_button_8.configure(state="disabled")
        self.sidebar_button_9.configure(state="disabled")
        self.sidebar_button_0.configure(state="disabled")
       
    # выбор уровня сложности угадывания
    def level_1_game(self,amount):
        print("level_1_game")
        global amount_mirror, Attempt, Stat, Case_number, Case, Level, Level2, Level3, Card_number, definite_Card_number, Card_num_1, Card_num_2, Card_num_3, Card_num_4
        amount = int(amount)
        Case = 0
        Card_num_1 = 0
        Card_num_2 = 0
        Card_num_3 = 0
        Card_num_4 = 0
        numbers_card = string.digits
        definite_Card_number = 0        
        if amount == 1:
            print("amount level 1")
            Case = random.randint(1, 10)
            Level = _("10 (разминка)")
            Level2 = _("4 цифры (разминка)")
            Level3 = _(" Выбор уровня недоступен. Усложнение постепенно.")
            Card_num_1 = random.randint(1000, 9999)
            definite_Card_number = int(str(Card_num_1))
            print("amount level 1 - " + str(Card_num_1))            
        if amount == 2:
            print("amount level 2")
            Level = _("100 (стандарт)")
            Case = random.randint(1, 100)
            Level2 = _("6 цифр (легко)")
            Level3 = _(" Выбор уровня недоступен. Усложнение постепенно.")
            Card_num_1 = random.randint(1000, 9999)
            Card_num_2 = ''.join(choice(numbers_card) for _ in range(2))
            definite_Card_number = int(str(Card_num_1) + str(Card_num_2))
            print("amount level 2 - "+ str(Card_num_1) + str(Card_num_2))
        if amount == 3:
            print("amount level 3")
            Level = _("1000 (профи)")
            Case = random.randint(1, 1000)
            Level2 = _("8 цифр (средне)")
            Level3 = _(" Выбор уровня недоступен. Усложнение постепенно.")
            Card_num_1 = random.randint(1000, 9999)
            Card_num_2 = ''.join(choice(numbers_card) for _ in range(2))
            Card_num_3 = ''.join(choice(numbers_card) for _ in range(2))
            definite_Card_number = int(str(Card_num_1) + str(Card_num_2) + str(Card_num_3))
            print("amount level 3 - "+ str(Card_num_1) + str(Card_num_2) + str(Card_num_3))
        if amount == 4:
            print("amount level 4")
            Level = _("10 000 (круто)")
            Case = random.randint(1, 10000)
            Level2 = _("10 цифр (норма)")
            Level3 = _(" Выбор уровня недоступен. Усложнение постепенно.")
            Card_num_1 = random.randint(1000, 9999)
            Card_num_2 = ''.join(choice(numbers_card) for _ in range(2))
            Card_num_3 = ''.join(choice(numbers_card) for _ in range(2))
            Card_num_4 = ''.join(choice(numbers_card) for _ in range(2))
            definite_Card_number = int(str(Card_num_1) + str(Card_num_2) + str(Card_num_3) + str(Card_num_4))
            print("amount level 4 - "+ str(Card_num_1) + str(Card_num_2) + str(Card_num_3) + str(Card_num_4))
        if amount == 5:
            print("amount level 5")
            Level = _("100 000 (сильно круто)")
            Case = random.randint(1, 100000)
            Level2 = _("12 цифр (сложно)")
            Level3 = _(" Выбор уровня недоступен. Усложнение постепенно.")
            Card_num_1 = random.randint(1000, 9999)
            Card_num_2 = ''.join(choice(numbers_card) for _ in range(4))
            Card_num_3 = ''.join(choice(numbers_card) for _ in range(2))
            Card_num_4 = ''.join(choice(numbers_card) for _ in range(2))
            definite_Card_number = int(str(Card_num_1) + str(Card_num_2) + str(Card_num_3) + str(Card_num_4))
            print("amount level 5 - "+ str(Card_num_1) + str(Card_num_2) + str(Card_num_3) + str(Card_num_4))
        if amount == 6:
            print("amount level 6")
            Level = _("1 000 000 (для продвинутых игроков)")
            Case = random.randint(1, 1000000)
            Level2 = _("16 цифр (круто)")
            Level3 = _(" Выбор уровня недоступен. Усложнение постепенно.")
            Card_num_1 = random.randint(1000, 9999)
            Card_num_2 = ''.join(choice(numbers_card) for _ in range(4))
            Card_num_3 = ''.join(choice(numbers_card) for _ in range(4))
            Card_num_4 = ''.join(choice(numbers_card) for _ in range(4))
            definite_Card_number = int(str(Card_num_1) + str(Card_num_2) + str(Card_num_3) + str(Card_num_4))
            print("amount level 6 - "+ str(Card_num_1) + str(Card_num_2) + str(Card_num_3) + str(Card_num_4))
        amount_mirror =  amount 
        Case_number = Case
        Card_number = definite_Card_number
        self.sidebar_button_11.configure(state="normal")
        self.sidebar_button_12.configure(state="normal")
        self.sidebar_button_13.configure(state="normal")        
        self.textbox.insert("1.0", "\n" +_(" Выбран уровень ") + str(amount) +" !" + "\n" * 2) 
        self.show_widget()
        self.play2()
        print("Case_number = " + str(Case))
  
    # начальные условия для def play_game(self)
    def new_game(self):
        print("new_game")
        global Case_number, Attempt, Stat, Case, amount, itern, game_selection
        self.button_status_1()
        Case_number = Case
        game_selection = 1
        Attempt = 1
        itern = a
        score = levelscore
        self.textbox.insert("0.0", _(" Угадай число:  от 1 до ") + str(Level) + "\n" * 1)
        self.entry.focus_set()
        self.entry.bind("<Return>", lambda event: [self.countdown(), self.level_score(), self.game_selection(), self.clear_form()])
        self.logo_info.configure(text = "     " + str(Level))        
        self.logo_info_status1.configure(text = str(score))
        self.logo_info_status2.configure(text = "[0]")
        self.logo_info_status3.configure(text = str(itern))
        self.sidebar_button_62.grid(row=9, column=0, padx=8, pady=10, sticky="n")
        self.sidebar_button_62.configure(state="normal")
        
    # функции игры 1       
    def play_game(self):
        self.play7()
        time.sleep(1.08)
        print("play_game")
        global Attempt, Stat, Case_number, amount, itern, a, stat_player_1
        Stat = 100 + 1 - Attempt*Attempt
        choic = int(self.entry.get())       
        itern = a
        self.select_player()
        print("itern start play game 1 " + str(itern))      
        self.progressbar_3.set(self.progressbar_3.get() + mass_2)
        if move_geme_progress[0] <= 0:
            self.game_end()        
        else:
            if Attempt == 14 and choic != Case_number:
                self.game_end()        
            if choic != Case_number and Attempt != 14:
                Attempt += 1
                self.logo_info_status2.configure(text = "[" + str(int((Attempt) - 1)) + "]")
                levelscore[0] -= 1000
                if move_geme_progress[0] > 0:
                    self.open_toplevel5()                
                if Case_number < choic:
                    self.color_tex_3()
                    self.textbox.insert("0.0", "\n" + str(Attempt - 1) + _(" попытка ")+ "\n" +
                                    _("Выбрано число - ") + str(choic) + "\n" + _("Не правильно!") + "\n" + _("Слишком БОЛЬШОЕ!") + "\n" * 3)
                    self.play5()                    
                if Case_number > choic:
                    self.color_tex_3()
                    self.textbox.insert("0.0", "\n" + str(Attempt - 1) + _(" попытка ")+ "\n" +
                                    _("Выбрано число - ") + str(choic) + "\n" + _("Не правильно!") + "\n" + _("Слишком МАЛЕНЬКОЕ!") + "\n" * 3)
                    self.play5()                      
            else:
                #self.textbox.insert("0.0", "\n" + "Попробуй еще раз" + "\n" +
                          #"...или не пробуй на свой страх и риск..." + "\n" * 2)
                self.play6()
                self.button_status_2()
                self.entry.unbind("<Return>", None)
                if Attempt == 14:
                    self.color_tex_2()
                    self.textbox.insert("0.0", _(" Какой опасный стиль игры!!") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("Все ")
                        + str(Attempt) + _(" попыток!.") + "\n" + _("Уровень интуиции = ") + str(Stat) + " % " + "\n\n")
                    time.sleep(2)
                    a[0] += 1000
                    self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                    print("itern game 1 = " + str(itern))                     
                if Attempt >= 6 and Attempt <= 13:
                    a[0] += 1000
                    self.progressbar_4.set(self.progressbar_4.get() - mass_1)
                    if Stat > 0:
                        self.color_tex_2()
                        self.textbox.insert("0.0", _(" Ну такое... жить можно...") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("Всего - ")
                        + str(Attempt) + _(" попыток.")+ "\n" + 
                        _("Уровень интуиции = ") + str(Stat) + _(" %  от нормы") + "\n\n".format(Attempt))
                        time.sleep(2)

                    if Stat <= 0:
                        self.color_tex_2()
                        self.textbox.insert("0.0", _(" Тревога!!! ")
                        + "\n" + str(Attempt) + _(" попыток ")+ "\n" + 
                         " " + "\n" + _("Уровень интуиции  =  ") + str(Stat) + " % " + "\n\n")
                        time.sleep(2)                        
                if Attempt == 5:
                    self.color_tex_2()
                    self.textbox.insert("0.0", _(" Нормально!") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("Всего лишь ")
                        + str(Attempt) + _(" попыток!.") + "\n" + _("Уровень интуиции = ") + str(Stat) + " % " + "\n\n")
                    time.sleep(2)
                    a[0] += 1000
                    self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                    print("itern game 1 = " + str(itern))
                if Attempt == 4:
                    self.color_tex_2()
                    self.textbox.insert("0.0", _(" Отлично!") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("Всего лишь ")
                        + str(Attempt) + _(" попытки!.") + "\n" + _("Уровень интуиции = ") + str(Stat) + " %  " + "\n\n")
                    time.sleep(2)
                    a[0] += 1000
                    self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                    print("itern game 1 =" + str(itern))
                if Attempt == 3:
                    self.color_tex_2()
                    self.textbox.insert("0.0", _(" Сильно!") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("Всего лишь ")
                        + str(Attempt) + _(" попытки!.") + "\n" + _("Уровень интуиции = ") + str(Stat) + " %  " + "\n\n")
                    time.sleep(2)
                    a[0] += 1000
                    self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                    print("itern game 1 =" + str(itern))
                if Attempt == 2:
                    self.color_tex_2()
                    self.textbox.insert("0.0", _(" Очень круто!") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("Почти сразу!") + "\n" + 
                    _("Уровень интуиции = ") + str(Stat) + " %  " + "\n\n")
                    time.sleep(2)
                    a[0] += 1000
                    self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                    print("itern game 1 =" + str(itern))
                if Attempt == 1:
                    self.color_tex_2()
                    self.textbox.insert("0.0", _(" Невероятно!") + "\n" + str(Case_number) + _(" - правильное число") + "\n" + _("С первого раза! ") + "\n" + 
                    _("Уровень интуиции = ") + str(Stat) + " %  " + "\n\n")
                    time.sleep(2)
                    a[0] += 1000
                    self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                    print("itern game 1 =" + str(itern))                                    
                print("itern game 1 end = " + str(itern))                
                self.iteration_game_1()                
            self.textbox.insert("0.0", self.textbox.get("1.0"))

    # начальные условия для def play_game_2(self)
    def new_game_2(self):
        print("new_game_2")
        global Attempt, amount, itern, Card_number, game_selection
        self.entry.bind("<Return>", lambda event: [self.countdown(), self.level_score(), self.game_selection(), self.clear_form()])
        self.button_status_1()
        game_selection = 2
        Attempt = 1
        itern = a
        score = levelscore
        self.textbox.insert("0.0", _(" Запомни   ") + str(Level2) + "\n" + _(" Нажми -  ПОКАЗАТЬ") + "\n" +
                                                                            _("Увеличь свою память до беспредела!!!") + "\n")
        self.entry.focus_set()
        self.logo_info.configure(text = "     " + str(Level2))
        self.sidebar_button_23.grid(row=4, column=0, padx=8, pady=10)
        self.sidebar_button_23.configure(state="normal")
        self.logo_info_status1.configure(text = str(score))
        self.logo_info_status2.configure(text = "[0]")
        self.logo_info_status3.configure(text = str(itern))
        self.sidebar_button_62.grid(row=9, column=0, padx=8, pady=10, sticky="n")
        self.sidebar_button_62.configure(state="normal")
        
    # функции игры 2       
    def play_game_2(self):
        print("play_game_2")
        self.play7()
        time.sleep(1.08)
        print("sidebar_button_10_Click called ENTER")
        global Attempt, amount, itern, Card_num_1, Card_num_2, Card_num_3, Card_num_4
        choic = int(self.entry.get())
        itern = a
        self.select_player()       
        self.progressbar_3.set(self.progressbar_3.get() + mass_2)        
        if choic != Card_number:
            Attempt += 1
            print("Attempt  = " + str(Attempt))
            self.logo_info_status2.configure(text = "[" + str(int((Attempt) - 1)) + "]")
            levelscore[0] -= 1000
            if Card_number != choic and Attempt != 4:
                self.color_tex_3()
                self.textbox.insert("0.0", "\n" + str(Attempt - 1) + _(" попытка ")+ "\n" +
                                    _("Введено число - ") + str(choic) + "\n" + _("Не правильно!") + "\n" * 3)
                self.play5()
                if move_geme_progress[0] > 0:
                    self.open_toplevel5()
            if Card_number != choic and Attempt == 4:
                print("Attempt = " + str(Attempt))
                self.game_end()
        else:
            self.play6()
            self.button_status_2()
            self.entry.unbind("<Return>", None) # уточнить команду
            self.textbox.delete("1.0", "end")    
            if Attempt == 3:
                self.progressbar_4.set(self.progressbar_4.get() - mass_1)
                self.color_tex_2()
                self.textbox.insert("0.0", _(" Ну такое... жить можно...") + "\n" + str(Card_number) + _(" - правильное число") + "\n" + _("Всего - ")
                + str(Attempt) + _(" попыток.") + "\n\n")
                time.sleep(2)
                a[0] += 1000
                print("itern game 2 = - 1" )  
            if Attempt == 2:
                self.color_tex_2()
                self.textbox.insert("0.0", _(" Очень круто!") + "\n" + str(Card_number) + _(" - правильное число") + "\n" + _("Почти сразу!") + "\n\n")
                time.sleep(2)
                a[0] += 1000
                self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                print("itern game 2 = " + str(itern))
            if Attempt == 1:
                self.color_tex_2()
                self.textbox.insert("0.0", _(" Невероятно!") + "\n" + str(Card_number) + _(" - правильное число") + "\n" + _("С первого раза! ") + "\n\n")
                time.sleep(2)
                a[0] += 1000
                self.progressbar_6.set(self.progressbar_6.get() + mass_4)
                print("itern game 2 = " + str(itern))                
            print("itern game 2 end = " + str(itern))
            self.iteration_game_1()            
        self.textbox.insert("0.0", self.textbox.get("1.0"))        
        if move_geme_progress[0] <= 0:
            self.game_end()

    # начальные условия для старта концентрации (шульте)
    def new_game_3(self):
        print("new_game_3")
        itern = a
        global game_selection     
        self.button_status_1()
        self.entry.configure(state="disabled")
        self.hide_enter_numeric()
        self.slider_button_15.configure(state="disabled")
        game_selection = 3
        self.select_player()
        self.clear_form()
        self.hide_widget()
        self.play3()                
        self.sidebar_button_38.grid(row=5, column=0, padx=8, pady=10, sticky="n")
        self.sidebar_button_38.configure(state="normal")
        self.sidebar_button_62.grid(row=9, column=0, padx=8, pady=10, sticky="n")
        self.sidebar_button_62.configure(state="normal")        
        self.textbox.insert("0.0", "\n" + _(" ") + "\n" + " " + str(Level3)
                             + "\n" + _(" Нажми -  НАЧАТЬ")  + "\n" + _("Прокачай концентрацию по полной!") + "\n" * 2)

    # функции выбора игры 1, 2, 3, прогресс бар и обратный отсчет ходов, прогресс очков уровня    
    def game_selection(self):
        print("game_selection")
        global game_selection
        if game_selection == 1:
            self.play_game()
            self.logo_info_status4.configure(text = str(count_down))
            self.progressbar_5.set(self.progressbar_5.get() - mass_3)
        if game_selection == 2:
            self.play_game_2()
            self.logo_info_status4.configure(text = str(count_down))
            self.progressbar_5.set(self.progressbar_5.get() - mass_3)
        if game_selection == 3:
            self.logo_info_status4.configure(text = str(count_down))
            self.progressbar_5.set(self.progressbar_5.get() - mass_3)

    # автостарт игры 1,2 - обратный отсчет ходов, прогресс очков уровня
    def autostart_game(self):
        print("autostart_game")
        if game_selection == 1:
            self.level_1_game(amount)
            self.new_game()
            self.hide_widget()
        if game_selection == 2:
            self.level_1_game(amount)
            self.new_game_2()
            self.hide_widget()
            
    # конец игры  
    def game_end(self):
        print("game_end")
        self.slider_button_15.configure(state="disabled")
        self.sidebar_button_23.grid_forget()
        self.sidebar_button_38.grid_forget()
        self.amount_slider_1.set(1)
        self.entry.unbind("<Return>", None)
        self.color_tex_3()
        self.textbox.delete("1.0", "end")
        self.level_pass()    
        if move_geme_progress[0] <= 0:
            self.open_toplevel13()
        else:
            self.open_toplevel10()

    # башня страданий
    def iteration_game_1(self):        
        print("replay iteration_game 1, 2")
        global amount
        self.progressbar_4.set(self.progressbar_4.get() + mass_1)
        if itern < [5000] and amount_mirror == 1:
            amount = 1
            self.autostart_game()         
        if itern < [5000] and amount_mirror != 1:
            self.progressbar_4.set(0)
            amount = 1
            self.amount_slider_1.set(1)
            a[0] = 0
            levelscore[0] = 0
            self.textbox.insert("0.0", _(" Молодец!!!") + "\n" + _(" - это была проба уровня,") + "\n" + _("Теперь давай по поядку! ") + "\n\n")
            self.autostart_game()            
        if itern == [5000] and amount == 1:
            self.progressbar_4.set(0)
            amount = 2
            self.amount_slider_1.set(2)
            a[0] == 6000
            levelscore[0] = 0
            self.level_pass()
            self.autostart_game()   
            self.open_toplevel2()            
        if itern >= [6000] and itern < [11000]:
            amount = 2
            self.amount_slider_1.set(2)
            self.autostart_game()
        if itern == [11000]:
            self.progressbar_4.set(0)
            amount = 3
            self.amount_slider_1.set(3)
            a[0] == 12000
            levelscore[0] = 0
            self.level_pass()
            self.autostart_game()
            self.open_toplevel2()                     
        if itern >= [12000] and itern < [17000]:
            amount = 3
            self.amount_slider_1.set(3)
            self.autostart_game()
        if itern == [17000]:
            self.progressbar_4.set(0)
            amount = 4
            self.amount_slider_1.set(4)
            a[0] == 18000
            levelscore[0] = 0
            self.level_pass()
            self.autostart_game()
            self.open_toplevel2()            
        if itern >= [18000] and itern < [23000]:
            amount = 4
            self.amount_slider_1.set(4)
            self.autostart_game()
        if itern == [23000]:
            self.progressbar_4.set(0)
            amount = 5
            self.amount_slider_1.set(5)
            a[0] == 24000
            levelscore[0] = 0
            self.level_pass()
            self.autostart_game()
            self.open_toplevel2()            
        if itern >= [24000] and itern < [29000]:
            amount = 5
            self.amount_slider_1.set(5)
            self.autostart_game()
        if itern == [29000]:
            self.progressbar_4.set(0)
            amount = 6
            self.amount_slider_1.set(6)
            a[0] == 30000
            levelscore[0] = 0
            self.level_pass()
            self.autostart_game()
            self.open_toplevel2()            
        if itern >= [30000] and itern < [35000]:
            amount = 6
            self.amount_slider_1.set(6)
            self.autostart_game()
        if itern == [35000]:
            self.entry.delete(0, customtkinter.END)
            self.entry.unbind("<Return>", None)
            self.entry.configure(state="disabled")
            self.level_pass()
            self.open_toplevel9() 

    # обратный отсчет ходов и фаталити при их оканчании
    def countdown(self):
        print("countdown")
        global count_down
        count_down = move_geme_progress
        if move_geme_progress[0] >= 0:
            if select_player == 1 :
                move_geme_progress[0] -= 1200
            if select_player == 2:
                move_geme_progress[0] -= 800
            if select_player == 3:
                move_geme_progress[0] -= 1000
        else:
            self.game_reset()
            
    # счет очков уровня
    def level_score(self):
        print("level_score")
        global score
        score = levelscore
        levelscore[0] += 1000

    # показать кнопку лабиринта реакция на "рэзеты"
    def show_widget(self):
        print("show_widget")
        global select_player
        if select_player == 1:
            if stat_player_1_game_1[0] >= 50 and stat_player_1_game_2[0] >= 25 and stat_player_1_game_3[0] >= 25:
                self.status_1_button_secret_level()
            else:
                self.status_2_button_secret_level()
        if select_player == 2:
            if stat_player_2_game_1[0] >= 25 and stat_player_2_game_2[0] >= 50 and stat_player_2_game_3[0] >= 25:
                self.status_1_button_secret_level()
            else:
                self.status_2_button_secret_level()
        if select_player == 3:
            if stat_player_3_game_1[0] >= 25 and stat_player_3_game_2[0] >= 25 and stat_player_3_game_3[0] >= 80:
                self.status_1_button_secret_level()
            else:
                self.status_2_button_secret_level()                
        self.sidebar_button_14.grid(row=11, column=0, padx=8, pady=(10, 10), sticky="s")
        if game_selection == 1 or game_selection == 2 or game_selection == 3:
            self.sidebar_button_62.grid(row=9, column=0, padx=8, pady=10, sticky="n")
            self.sidebar_button_62.configure(state='normal')
        time.sleep(0.2)
        
    # скрыть кнопки игр показать кнопку смены игр
    def hide_widget(self):
        print("hide_widget")
        self.sidebar_button_11.grid_forget()
        self.sidebar_button_12.grid_forget()
        self.sidebar_button_13.grid_forget()
        self.sidebar_button_58.grid_forget()
        time.sleep(0.2)
        
    # тема
    def change_appearance_mode_event(self, new_appearance_mode: str):
        print("change_appearance_mode_event")
        self.play4()
        customtkinter.set_appearance_mode(new_appearance_mode)
    
    # масштаб
    def change_scaling_event(self, new_scaling: str):
        print("change_scaling_event")
        self.play4()
        new_scaling_float = int(new_scaling.replace("%", "")) / 100
        customtkinter.set_widget_scaling(new_scaling_float)

    # кнопки слайдера
    def slider_level_1(self):
        amount = 1
        self.level_1_game(amount)
        self.amount_slider_1.set(1)
    def slider_level_2(self):
        amount = 2
        self.level_1_game(amount)
        self.amount_slider_1.set(2)
    def slider_level_3(self):
        amount = 3
        self.level_1_game(amount)
        self.amount_slider_1.set(3)
    def slider_level_4(self):
        amount = 4
        self.level_1_game(amount)
        self.amount_slider_1.set(4)
    def slider_level_5(self):
        amount = 5
        self.level_1_game(amount)
        self.amount_slider_1.set(5)
    def slider_level_6(self):
        amount = 6
        self.level_1_game(amount)
        self.amount_slider_1.set(6)

    # числовые кнопки  
    def button_1(self):
        self.play8()
        self.entry.insert(END, 1)
        print("button 1")
    def button_2(self):
        self.play8()
        self.entry.insert(END, 2)
        print("button 2")
    def button_3(self):
        self.play8()
        self.entry.insert(END, 3)
        print("button 3")
    def button_4(self):
        self.play8()
        self.entry.insert(END, 4)
        print("button 4")
    def button_5(self):
        self.play8()
        self.entry.insert(END, 5)
        print("button 5")
    def button_6(self):
        self.play8()
        self.entry.insert(END, 6)
        print("button 6")
    def button_7(self):
        self.play8()
        self.entry.insert(END, 7)
        print("button 7")
    def button_8(self):
        self.play8()
        self.entry.insert(END, 8)
        print("button 8")
    def button_9(self):
        self.play8()
        self.entry.insert(END, 9)
        print("button 9")
    def button_0(self):
        self.play8()
        self.entry.insert(END, 0)
        print("button 0")

    #  регулировка спектра fg_color кнопок.
    def reset_color(self, var, index, mode):
        color = '#'
        color += f"{self.rgb_variables['Red'].get():02x}"
        color += f"{self.rgb_variables['Green'].get():02x}"
        color += f"{self.rgb_variables['Blue'].get():02x}"
        print("rgb_variables[color]")
        self.sidebar_button_0.configure(fg_color=color)
        self.sidebar_button_1.configure(fg_color=color)
        self.sidebar_button_2.configure(fg_color=color)
        self.sidebar_button_3.configure(fg_color=color)
        self.sidebar_button_4.configure(fg_color=color)
        self.sidebar_button_5.configure(fg_color=color)
        self.sidebar_button_6.configure(fg_color=color)
        self.sidebar_button_7.configure(fg_color=color)
        self.sidebar_button_8.configure(fg_color=color)
        self.sidebar_button_9.configure(fg_color=color)
        self.sidebar_button_10.configure(fg_color=color)        
        self.sidebar_button_11.configure(fg_color=color)
        self.sidebar_button_12.configure(fg_color=color)
        self.sidebar_button_13.configure(fg_color=color)
        self.sidebar_button_14.configure(fg_color=color)
        self.sidebar_button_15.configure(fg_color=color)
        self.sidebar_button_16.configure(fg_color=color)
        self.sidebar_button_23.configure(fg_color=color)
        self.sidebar_button_38.configure(fg_color=color)
        self.sidebar_button_55.configure(fg_color=color)
        self.sidebar_button_58.configure(fg_color=color)
        self.sidebar_button_62.configure(fg_color=color)        
        self.slider_button_15.configure(fg_color=color)
        #self.appearance_mode_optionemenu.configure(fg_color=color)     # не удалять
        #self.scaling_optionemenu.configure(fg_color=color)             # не удалять
        self.sidebar1_frame.configure(border_color=color)
        self.sidebar3_frame.configure(border_color=color)
        self.slider4_progressbar_frame.configure(border_color=color)
        self.textbox.configure(border_color=color)
        self.sidebar0_frame.configure(border_color=color)
        self.entry.configure(border_color=color)
        self.slider_button_17.configure(fg_color=color)
        self.slider_button_18.configure(fg_color=color)
        self.slider_button_19.configure(fg_color=color)
        self.slider_button_20.configure(fg_color=color)
        self.slider_button_21.configure(fg_color=color)
        self.slider_button_22.configure(fg_color=color)
        self.amount_slider_1.configure(border_color=color)
        self.progressbar_3.configure(border_color=color)
        self.progressbar_4.configure(border_color=color)
        self.progressbar_5.configure(border_color=color)
        self.progressbar_6.configure(border_color=color)        
        self.progressbar_1.configure(progress_color=color)
        self.progressbar_2.configure(progress_color=color)
        self.progressbar_7.configure(progress_color=color)
        self.progressbar_8.configure(progress_color=color)
        self.tabview.configure(border_color=color, segmented_button_selected_color=color)
        self.slider4_progressbar_2_frame.configure(border_color=color)
        self.button_28.configure(fg_color=color)
        self.button_29.configure(fg_color=color)
        self.button_30.configure(fg_color=color)
        self.logo_label_title.configure(text_color=color)
        self.canvas_1.configure(bg=color)
        self.canvas_2.configure(bg=color)
        self.canvas_3.configure(bg=color)
        self.canvas_10.configure(bg=color)
        self.sidebar_button_80.configure(fg_color=color)

    # хитрая функция спектра    
    def create_rgb_sliders(self):
        self.rgb = ["Red","Green","Blue"]
        self.rgb_variables = {}
        print("create_rgb_sliders")
        for color in self.rgb:           
            self.rgb_variables[color] = customtkinter.IntVar()
            self.rgb_variables[color].trace_add('write', self.reset_color)            
            self.slider = customtkinter.CTkSlider(self, width=20, height=250, from_=0, to=255, orientation="vertical", variable=self.rgb_variables[color])
            self.slider.grid(column=self.rgb.index(color) + 1, row=2, rowspan=4, padx=2, pady=(5, 28), sticky="snwe")
                
    # звук старта игры
    def play0(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/focus loop.aiff")
        pygame.mixer.music.play(-1) 
        pygame.mixer.music.set_volume(1)
        
    # звук повышения уровня
    def play1(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/start.mp3")
        pygame.mixer.music.play(-1)   
        pygame.mixer.music.set_volume(1)
        
    # звук выбора сложности
    def play2(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/level.wav")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук кнопок левой панели
    def play3(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/game.wav")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук масштаба и темы
    def play4(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/scalemod2.wav")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук хода
    def play5(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/nowins.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук победы
    def play6(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/wins.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук ввода
    def play7(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/enter.wav")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук кнопок
    def play8(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/clickbuttons.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук отмены
    def play9(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/delete.wav")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук рестарта
    def play10(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/restart.wav")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук выхода
    def play11(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/exit.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук ожидания в шультэ  
    def play12(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/massive pulse loop.aiff")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук шага
    def play13(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/korotkiy-zvonkiy-bodryiy-zvuk-shaga.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук телепорта
    def play14(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/teleport.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)
        
    # звук прохода
    def play15(self):
        pygame.mixer.music.load("/home/lord/MEGAsync/books/python/Oracl/audio/brosili-ogromnyiy-kamen.mp3")
        pygame.mixer.music.play() 
        pygame.mixer.music.set_volume(1)

    # вызов окна завершения программы
    def open_toplevel1(self):
        self.play11()
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel1Window(self)
        else:
            self.toplevel_window.grab_set()
               
    # вызов окна повышения уровня
    def open_toplevel2(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel2Window(self) 
        else:
            self.toplevel_window.focus()

    # вызов окна справки
    def open_toplevel3(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel3Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна чисел карты
    def open_toplevel4(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel4Window(self)
        else:
            self.toplevel_window.focus()
            
    # вызов окна совета
    def open_toplevel5(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel5Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна описания игрока 1
    def open_toplevel6(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel6Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна описания игрока 2
    def open_toplevel7(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel7Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна описания игрока 3
    def open_toplevel8(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel8Window(self)
        else:
            self.toplevel_window.focus()
            
    # вызов окна победы
    def open_toplevel9(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel9Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна проигрыша по штрафам
    def open_toplevel10(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel10Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна лабиринта 1
    def open_toplevel11(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel11Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна концентрации
    def open_toplevel12(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel12Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна окончания бодрости
    def open_toplevel13(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel13Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна смны языков
    def open_toplevel14(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel14Window(self)
        else:
            self.toplevel_window.focus()

    # вызов окна старта
    def open_toplevel15(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel15Window(self)
        else:
            self.toplevel_window.focus()
            
     # вызов победы в лабиринте
    def open_toplevel16(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = Toplevel16Window(self)
        else:
            self.toplevel_window.focus()

    # назначениe цвета в textbox
    def color_tex_1(self): # нейтральный
        print("color_tex_1")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), text_color="#5d94d5")
    def color_tex_2(self): # верно
        print("color_tex_2")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), text_color="#1cb800")
    def color_tex_3(self):# не верно
        print("color_tex_3")
        self.textbox.configure(font=customtkinter.CTkFont(size=22), text_color="#ff3e00")

    # очистка поля ввода
    def clear_form(self):
        print("clear_form")
        self.entry.delete(0, customtkinter.END)
        self.entry.focus_set()
        #return None
    
    # отмена ввода числа
    def backspace(self):
        print("backspace")
        self.play9()
        self.entry.delete(len(self.entry.get())-1, END)

    # изменения списков характеристик при прохождении уровня штрафов и заканчивании бодрости
    def level_pass(self):
        print("level_pass")
        global balanser_reset
        balancer_1 = 0
        balancer_2 = 0
        balancer_3 = 0    
        balancer_text = ""
        self.entry.delete(0, customtkinter.END)                    
        if select_player == 1:
            if balanser_reset == 1:
                balancer_1 = 0.92
                balancer_2 = 0.98
                balancer_3 = 0.98
                balancer_text = (_(" Игру сбросил ") + str(hero_name) + "!\n\n" + _("   Отлично, герой! ") + 
                                   "\n" + _("Получены штрафы!") + "\n" + str(hero_name) + _("приносит минимальные штрафы своей команде жертвуя собой:") +
                                                                                  "\n" + _(" Psiheiya = -8% от имеющихся характеристик")+
                                                                                  "\n" + _(" Golem = -2% от имеющихся характеристик") +
                                                                                  "\n" + _(" Expand = -2% от имеющихся характеристик") + "\n")
            else:
                if Attempt == 14 or Attempt == 4 and game_selection == 2:
                    balancer_1 = 0.95
                    balancer_2 = 1.1
                    balancer_3 = 1.1
                    balancer_text = (_(" Вот и все...") + "\n" + str(hero_name) + _("приносит бонусы своей команде жертвуя собой:") + "\n"
                                     + _(" Psiheiya = -5% от имеющихся характеристик") +
                                            "\n" + _(" Golem = +1% к имеющимся характеристикам") + "\n" + _(" Expand = +1% к имеющимся характеристикам"))
                    self.entry.configure(state="disabled")
                    self.progressbar_5.set(1)
                    levelscore[0] = 0
                    self.common_end()
                  
                if move_geme_progress[0] <= 0:
                    balancer_1 = 0.5
                    balancer_2 = 0.8
                    balancer_3 = 0.8
                    balancer_text = (_(" Вот и все...") + "\n" + str(hero_name) + _("приносит минимальные штрафы своей команде:") +
                                                                                  "\n" + _(" Psiheiya = -50% от имеющихся характеристик") +
                                                                                  "\n" + _(" Golem = -20% от имеющихся характеристик") +
                                                                                  "\n" + _(" Expand = -20% от имеющихся характеристик"))
                    self.entry.configure(state="disabled")
                    self.progressbar_5.set(1)
                    levelscore[0] = 0
                    move_geme_progress[0] = 0
                    self.common_end()
                if move_geme_progress[0] > 0 and Attempt != 4 and game_selection == 2 or \
                    move_geme_progress[0] > 0 and Attempt != 14 and game_selection == 1:                    
                    if amount == 1:
                        pass                    
                    if amount == 2:
                        balancer_1 = 1.01
                        balancer_2 = 1.005
                        balancer_3 = 1.005
                        balancer_text = (str(hero_name) + _("приносит своей команде:") +
                        "\n" + _(" Psiheiya = +1% к имеющимся характеристикам") +"\n" + _(" Golem = +0.5% к имеющимся характеристикам") +
                                                                              "\n" + _(" Expand = +0.5% к имеющимся характеристикам") + "\n")
                    if amount == 3:
                        balancer_1 = 1.02
                        balancer_2 = 1.006
                        balancer_3 = 1.006
                        balancer_text = (str(hero_name) + _("приносит своей команде:") +
                        "\n" + _(" Psiheiya = +2% к имеющимся характеристикам") +"\n" + _(" Golem = +0.6% к имеющимся характеристикам") + "\n" +
                                                                                     _(" Expand = +0.6% к имеющимся характеристикам") + "\n")
                    if amount == 4:
                        balancer_1 = 1.03
                        balancer_2 = 1.007
                        balancer_3 = 1.007
                        balancer_text = (str(hero_name) + _("приносит своей команде:") +
                        "\n" + _(" Psiheiya = +3% к имеющимся характеристикам") +"\n" + _(" Golem = +0.7% к имеющимся характеристикам") +
                                                                              "\n" + _(" Expand = +0.7% к имеющимся характеристикам") + "\n")
                    if amount == 5:
                        balancer_1 = 1.04
                        balancer_2 = 1.008
                        balancer_3 = 1.008
                        balancer_text = (str(hero_name) + _("приносит своей команде:") +
                        "\n" + _(" Psiheiya = +4% к имеющимся характеристикам") +"\n" + _(" Golem = +0.8% к имеющимся характеристикам") +
                                                                              "\n" + _(" Expand = +0.8% к имеющимся характеристикам") + "\n")
                    if amount == 6:
                        balancer_1 = 1.05
                        balancer_2 = 1.009
                        balancer_3 = 1.009
                        balancer_text = (_(" НАШИ ПОЗДРАВЛЕНИЯ!!! ") +   "\n\n"
                                         + _("Сделайте скрин и отправте нам на почту для вступления в клуб") + "\n\n" +
                                         str(hero_name) +  _("приносит своей команде:") +
                        "\n" + _(" Psiheiya = +5% к имеющимся характеристикам") +"\n" + _(" Golem = +0.9% к имеющимся характеристикам") +
                                                                              "\n" + _(" Expand = +0.9% к имеющимся характеристикам") + "\n") 
        if select_player == 2:

            if balanser_reset == 1:
                balancer_1 = 0.95
                balancer_2 = 0.95
                balancer_3 = 0.95
                balancer_text = (_(" Игру сбросил ") + str(hero_name) + "!\n\n" + _("   Отлично, герой! ") + 
                                               "\n" + _("Получены штрафы!") + "\n" + str(hero_name) + _("распределяет штрафы своей команде:") +
                                                                                  "\n" + _(" Psiheiya = -5% от имеющихся характеристик") +
                                                                                  "\n" + _(" Golem = -5% от имеющихся характеристик") +
                                                                                  "\n" + _(" Expand = -5% от имеющихся характеристик") + "\n")
            else:
                if Attempt == 14 or Attempt == 4 and game_selection == 2:
                    balancer_1 = 1
                    balancer_2 = 0.98
                    balancer_3 = 1
                    balancer_text = (_("Вот и все...") + "\n" + str(hero_name) + _("не позволяет штрафовать других:") + "\n" + _(" Golem = -2% развития"))
                    self.entry.configure(state="disabled")
                    self.progressbar_5.set(1)
                    levelscore[0] = 0
                    self.common_end()            
                if move_geme_progress[0] <= 0:
                    balancer_1 = 0.5
                    balancer_2 = 0.5
                    balancer_3 = 0.5
                    balancer_text = (_(" Вот и все...") + "\n" + str(hero_name) + _("приносит штрафы своей команде:") + "\n" +
                                     _(" Psiheiya = -50% от имеющихся характеристик") +
                                       "\n" + _(" Golem = -50% от имеющихся характеристик") + "\n" + _(" Expand = -50% от имеющихся характеристик"))
                    self.entry.configure(state="disabled")
                    self.progressbar_5.set(1)
                    levelscore[0] = 0
                    move_geme_progress[0] = 0
                    self.common_end()                   
                if move_geme_progress[0] > 0 and Attempt != 4 and game_selection == 2 or \
                    move_geme_progress[0] > 0 and Attempt != 14 and game_selection == 1:                    
                    if amount == 1:
                        pass
                    if amount == 2:
                        balancer_1 = 1
                        balancer_2 = 1.002
                        balancer_3 = 1
                        balancer_text = (str(hero_name) + _("повышает свои характеристики: +0.02%") + "\n")
                    if amount == 3:
                        balancer_1 = 1
                        balancer_2 = 1.003
                        balancer_3 = 1
                        balancer_text = (str(hero_name) + _("повышает свои характеристики: +0.03%") + "\n")
                    if select_player == 2 and amount == 4:
                        balancer_1 = 1
                        balancer_2 = 1.004
                        balancer_3 = 1
                        balancer_text = (str(hero_name) + _("повышает свои характеристики: +0.04%") + "\n")
                    if amount == 5:
                        balancer_1 = 1
                        balancer_2 = 1.005
                        balancer_3 = 1
                        balancer_text = (str(hero_name) + _("повышает свои характеристики: +0.05%") + "\n")
                    if amount == 6:
                        balancer_1 = 1
                        balancer_2 = 1.006
                        balancer_3 = 1
                        balancer_text = (_(" НАШИ ПОЗДРАВЛЕНИЯ!!! ") +  "\n\n"
                                         + _("Сделайте скрин и отправте нам на почту для вступления в клуб")+ "\n\n" +
                                         str(hero_name) + _("повышает свои характеристики: +0.06%") + "\n")
        if select_player == 3:
            if balanser_reset == 1:
                balancer_1 = 0.95
                balancer_2 = 0.98
                balancer_3 = 0.98
                balancer_text = (_(" Игру сбросил ") + str(hero_name) + "!\n\n" + _("   Отлично, герой! ") + 
                                               "\n" + _("Получены штрафы!") + "\n" + str(hero_name) + _("приносит максимальные штрафы но только не себе:") +
                                                                                  "\n" + _(" Psiheiya = -8% от имеющихся характеристик") +
                                                                                  "\n" + _(" Golem = -8% от имеющихся характеристик") +
                                                                                  "\n" + _(" Expand = -2% от имеющихся характеристик") + "\n")
            else:
                if Attempt == 14 or Attempt == 4 and game_selection == 2:
                    balancer_1 = 0.98
                    balancer_2 = 0.98
                    balancer_3 = 0.98
                    balancer_text = (_("Вот и все...") + "\n" + str(hero_name) + _("приносит штрафы своей команде:") + "\n" +
                                     _(" Psiheiya = -2% от имеющихся характеристик") +
                                         "\n" + _(" Golem = -2% от имеющихся характеристик") + "\n" + _(" Expand = -2% от имеющихся характеристик"))                    
                    self.entry.configure(state="disabled")
                    self.progressbar_5.set(1)
                    levelscore[0] = 0
                    self.common_end()
                if move_geme_progress[0] <= 0:
                    balancer_1 = 0.2
                    balancer_2 = 0.2
                    balancer_3 = 0.8
                    balancer_text = (_(" Вот и все...") + "\n" + str(hero_name) + _("перераспределяет штрафы в свою пользу:") +
                                     "\n" + _(" Psiheiya = -80% от имеющихся характеристик") +
                                       "\n" + _(" Golem = -80% от имеющихся характеристик") + "\n" + _(" Expand = -20% от имеющихся характеристик"))
                    self.entry.configure(state="disabled")
                    self.progressbar_5.set(1)
                    levelscore[0] = 0
                    move_geme_progress[0] = 0
                    self.common_end()                    
                if move_geme_progress[0] > 0 and Attempt != 4 and game_selection == 2 or \
                    move_geme_progress[0] > 0 and Attempt != 14 and game_selection == 1:                    
                    if amount == 1:
                        pass
                    if amount == 2:
                        balancer_1 = 1
                        balancer_2 = 1
                        balancer_3 = 1.003
                        balancer_text = (str(hero_name) + _("добывает себе:") + "\n" + _(" +0.03% к имеющимся характеристикам") + "\n")
                    if amount == 3:
                        balancer_1 = 1
                        balancer_2 = 1
                        balancer_3 = 1.004
                        balancer_text = (str(hero_name) + _("добывает себе:") + "\n" + _(" +0.04% к имеющимся характеристикам") + "\n")
                    if amount == 4:
                        balancer_1 = 1
                        balancer_2 = 1
                        balancer_3 = 1.005
                        balancer_text = (str(hero_name) + _("добывает себе:") + "\n" + _(" +0.05% к имеющимся характеристикам") + "\n")
                    if amount == 5:
                        balancer_1 = 1
                        balancer_2 = 1
                        balancer_3 = 1.006
                        balancer_text = (str(hero_name) + _("добывает себе:") + "\n" + _(" +0.06% к имеющимся характеристикам") + "\n")
                    if amount == 6:
                        balancer_1 = 1
                        balancer_2 = 1
                        balancer_3 = 1.007
                        balancer_text = (_(" НАШИ ПОЗДРАВЛЕНИЯ!!! ") +   "\n\n"
                                         + _("Сделайте скрин и отправте нам на почту для вступления в клуб") + "\n\n" +
                                         str(hero_name) + _("добывает себе:") + "\n" + _(" +0.07% к имеющимся характеристикам") + "\n")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
            file_stat_player_1_game_1 = f.read()
        stat_player_1_game_1 = [0]    
        stat_player_1_game_1[0] = float(file_stat_player_1_game_1)
        stat_player_1_game_1[0] *= float(balancer_1)
        list_stat_player_1_game_1 = str(stat_player_1_game_1[0])
        file_stat_player_1_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'w')
        for element in list_stat_player_1_game_1:
                file_stat_player_1_game_1.write(element)
        file_stat_player_1_game_1.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game1.txt", 'r') as f:
            file_stat_player_1_game_1 = f.read()
        self.logo_label_2_player_1.configure(text=_("Интуиция = ") + str(file_stat_player_1_game_1[0:4]) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
            file_stat_player_1_game_2 = f.read()       
        stat_player_1_game_2 = [0]    
        stat_player_1_game_2[0] = float(file_stat_player_1_game_2)    
        stat_player_1_game_2[0] *= float(balancer_1) 
        list_stat_player_1_game_2 = str(stat_player_1_game_2[0])
        file_stat_player_1_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'w')
        for element in list_stat_player_1_game_2:
                file_stat_player_1_game_2.write(element)
        file_stat_player_1_game_2.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game2.txt", 'r') as f:
            file_stat_player_1_game_2 = f.read()
        self.logo_label_3_player_1.configure(text=_("Память = ") + str('%.4s' % file_stat_player_1_game_2) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
            file_stat_player_1_game_3 = f.read()  
        stat_player_1_game_3 = [0]    
        stat_player_1_game_3[0] = float(file_stat_player_1_game_3)
        stat_player_1_game_3[0] *= float(balancer_1)                   
        list_stat_player_1_game_3 = str(stat_player_1_game_3[0])
        file_stat_player_1_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'w')
        for element in list_stat_player_1_game_3:
            file_stat_player_1_game_3.write(element)
        file_stat_player_1_game_3.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer1game3.txt", 'r') as f:
            file_stat_player_1_game_3 = f.read()
        self.logo_label_4_player_1.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_1_game_3) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
            file_stat_player_2_game_1 = f.read()                   
        stat_player_2_game_1 = [0]    
        stat_player_2_game_1[0] = float(file_stat_player_2_game_1)        
        stat_player_2_game_1[0] *= float(balancer_2)            
        list_stat_player_2_game_1 = str(stat_player_2_game_1[0])
        file_stat_player_2_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'w')          
        for element in list_stat_player_2_game_1:
                file_stat_player_2_game_1.write(element)
        file_stat_player_2_game_1.close()            
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game1.txt", 'r') as f:
            file_stat_player_2_game_1 = f.read()
        self.logo_label_2_player_2.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_2_game_1) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
            file_stat_player_2_game_2 = f.read()                   
        stat_player_2_game_2 = [0]    
        stat_player_2_game_2[0] = float(file_stat_player_2_game_2)      
        stat_player_2_game_2[0] *= float(balancer_2)             
        list_stat_player_2_game_2 = str(stat_player_2_game_2[0])
        file_stat_player_2_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'w')                
        for element in list_stat_player_2_game_2:
                file_stat_player_2_game_2.write(element)
        file_stat_player_2_game_2.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game2.txt", 'r') as f:
            file_stat_player_2_game_2 = f.read()
        self.logo_label_3_player_2.configure(text=_("Память = ") + str('%.4s' % file_stat_player_2_game_2) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
            file_stat_player_2_game_3 = f.read()              
        stat_player_2_game_3 = [0]    
        stat_player_2_game_3[0] = float(file_stat_player_2_game_3)         
        stat_player_2_game_3[0] *= float(balancer_2)          
        list_stat_player_2_game_3 = str(stat_player_2_game_3[0])
        file_stat_player_2_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'w')         
        for element in list_stat_player_2_game_3:
                file_stat_player_2_game_3.write(element)
        file_stat_player_2_game_3.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer2game3.txt", 'r') as f:
            file_stat_player_2_game_3 = f.read()
        self.logo_label_4_player_2.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_2_game_3) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
            file_stat_player_3_game_1 = f.read()             
        stat_player_3_game_1 = [0]    
        stat_player_3_game_1[0] = float(file_stat_player_3_game_1)         
        stat_player_3_game_1[0] *= float(balancer_3)       
        list_stat_player_3_game_1 = str(stat_player_3_game_1[0])
        file_stat_player_3_game_1 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'w')      
        for element in list_stat_player_3_game_1:
                file_stat_player_3_game_1.write(element)
        file_stat_player_3_game_1.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game1.txt", 'r') as f:
            file_stat_player_3_game_1 = f.read()
        self.logo_label_2_player_3.configure(text=_("Интуиция = ") + str('%.4s' % file_stat_player_3_game_1) + "%")          
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
            file_stat_player_3_game_2 = f.read()            
        stat_player_3_game_2 = [0]    
        stat_player_3_game_2[0] = float(file_stat_player_3_game_2)      
        stat_player_3_game_2[0] *= float(balancer_3)      
        list_stat_player_3_game_2 = str(stat_player_3_game_2[0])
        file_stat_player_3_game_2 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'w')        
        for element in list_stat_player_3_game_2:
                file_stat_player_3_game_2.write(element)
        file_stat_player_3_game_2.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game2.txt", 'r') as f:
            file_stat_player_3_game_2 = f.read()
        self.logo_label_3_player_3.configure(text=_("Память = ") + str('%.4s' % file_stat_player_3_game_2) + "%")
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
            file_stat_player_3_game_3 = f.read()             
        stat_player_3_game_3 = [0]    
        stat_player_3_game_3[0] = float(file_stat_player_3_game_3)       
        stat_player_3_game_3[0] *= float(balancer_3)          
        list_stat_player_3_game_3 = str(stat_player_3_game_3[0])
        file_stat_player_3_game_3 = open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'w')          
        for element in list_stat_player_3_game_3:
                file_stat_player_3_game_3.write(element)
        file_stat_player_3_game_3.close()
        with open("/home/lord/MEGAsync/books/python/Oracl/text/statplayer3game3.txt", 'r') as f:
            file_stat_player_3_game_3 = f.read()
        self.logo_label_4_player_3.configure(text=_("Концентрация = ") + str('%.4s' % file_stat_player_3_game_3) + "%")
        self.textbox.delete("1.0", "end")
        self.textbox.insert("0.0", "\n" + str(balancer_text))
        balanser_reset = 0
        
    # функции при выборе игрока
    def reset_on_player_selection(self):
        print("reset_on_player_selection")
        if game_selection == 1 or game_selection == 2 or game_selection == 3:
            self.show_widget()
            self.color_tex_1()
            self.logo_info.configure(text = _(" Играет") + str(hero_name))    
            self.logo_info_status11.configure(text = _("за уровень"))
            self.logo_info_status12.configure(text = _("ошибки"))
            self.logo_info_status13.configure(text = _("за игру"))
            self.logo_info_status14.configure(text = _("бодрость"))
            self.sidebar_button_11.grid_forget()
            self.sidebar_button_12.grid_forget()
            self.sidebar_button_13.grid_forget()
            self.sidebar_button_58.grid_forget()
            self.textbox.insert("0.0", "\n" + _(" Игру перехватывает") + str(hero_name) + "!\n\n" +
                                                            _("   Вперед, герой! ") + "\n")
        else:
            self.common_end()
            
    # функции при смене игры
    def reset_on_game_selection(self):
        print("reset_on_game_selection")
        global game_selection
        self.show_widget()
        self.color_tex_1()
        self.textbox.delete("1.0", "end")
        self.textbox.insert("0.0", _(" Начни новое испытание!") + "\n")
        self.entry.delete(0, customtkinter.END)
        game_selection = 0
        self.button_status_2()
        self.common_end()
            
    # сброс игры или конец игры при заканчивании очков бодрости
    def game_reset(self):
        print("game_reset")
        global game_selection
        self.progressbar_5.set(1)
        self.logo_info_status4.configure(text = "[100000]")
        move_geme_progress[0] = 100000
        levelscore[0] = 0
        if game_selection != 0:
            game_selection = 0
            self.entry.delete(0, customtkinter.END)
        self.entry.delete(0, customtkinter.END)
        self.common_end()
        
    # сброс кнопкой
    def button_game_reset(self):
        print("button_game_reset")
        global balanser_reset
        global game_selection
        balanser_reset = 1
        self.progressbar_5.set(1)
        self.logo_info_status4.configure(text = "[100000]")
        move_geme_progress[0] = 100000
        levelscore[0] = 0
        game_selection = 0
        self.entry.delete(0, customtkinter.END)
        self.common_end()
        self.level_pass()
 
    # общие функциии при сбросе игры окончаниии или смене игрока обновлении уровня или его смене 
    def common_end(self):
        print("common_end ")
        self.show_widget()
        self.hide_widget()
        self.color_tex_1()
        self.logo_info.configure(text = _(" Играет") + str(hero_name))
        a[0] = 0
        self.slider_level_1()
        self.sidebar_button_23.grid_forget()
        self.sidebar_button_38.grid_forget()
        self.sidebar_button_62.grid_forget()
        self.sidebar_button_62.configure(state='disabled')
        self.progressbar_3.set(0)
        self.progressbar_4.set(0)  
        self.progressbar_6.set(0)
        self.entry.unbind("<Return>", None)
        self.entry.configure(state="disabled")
        self.logo_info_status1.configure(text = "[0]")
        self.logo_info_status2.configure(text = "[0]")
        self.logo_info_status3.configure(text = "[0]")        
        self.logo_info_status11.configure(text = _("за уровень"))
        self.logo_info_status12.configure(text = _("ошибки"))
        self.logo_info_status13.configure(text = _("за игру"))
        self.logo_info_status14.configure(text = _("бодрость"))        
        if game_selection != 1 or game_selection != 2 or game_selection != 3:
            self.entry.configure(state="disabled")
            self.show_widget()
            self.sidebar_button_11.grid(row=0, column=0, padx=8, pady=(8, 10))
            self.sidebar_button_12.grid(row=1, column=0, padx=8, pady=(8, 10))
            self.sidebar_button_13.grid(row=2, column=0, padx=8, pady=(8, 10))
            self.textbox.insert("0.0", "\n" + _(" Играет") + str(hero_name) + "!\n\n" +
                                                            _("   Вперед, герой! ") + "\n" +  _("Следует ознакомится с правилами заранее!") +
                                "\n" + _("Это даст возможность не притормаживать в развитии..."))
        if move_geme_progress[0] <= 0:
            self.end_hide_widget()
            self.textbox.delete("1.0", "end")
            self.textbox.insert("0.0", "!\n\n" + _("   Вперед, герой! ") + "\n" + 
                                         "\n" + _("Следует ознакомится с правилами заранее!") + "\n" + _("Это даст возможность не притормаживать в развитии..."))

    # скрытие кнопок при окончании бодрости
    def end_hide_widget(self):
        print("end_hide_widget ")
        game_selection = 0
        self.hide_enter_numeric()
        self.hide_widget()
        self.slider4_progressbar_2_frame.grid_forget()
        self.sidebar_button_58.grid_forget()
        self.sidebar_button_62.grid_forget()
        self.sidebar_button_62.configure(state='disabled')
        self.sidebar_button_55.grid(row=10, column=0, padx=8, pady=(10, 10), sticky="s")
        self.sidebar_button_55.configure(state="normal")
        self.sidebar_button_14.grid_forget()
        self.tabview.grid_forget()
        self.sidebar4_frame.grid(row=1, column=9, rowspan=2, padx=(2, 5), pady=(2, 5), sticky="nsew")
        
    # восстановление начальных условий после нажатии на кнопку "начать заново"
    def new_game_reset(self):
        print("new_game_reset")
        global game_selection
        self.button_status_2()
        self.color_tex_2()
        self.logo_info.configure(text = _(" Новый раунд" ))
        a[0] = 0
        self.slider_level_1()
        self.sidebar_button_23.grid_forget()
        self.sidebar_button_38.grid_forget()  
        self.sidebar_button_62.grid_forget()
        self.sidebar_button_62.configure(state='disabled')
        self.sidebar_button_55.grid_forget()
        self.sidebar_button_55.configure(state="disabled")       
        self.sidebar_button_11.grid_forget()
        self.sidebar_button_12.grid_forget()
        self.sidebar_button_13.grid_forget()
        self.sidebar_button_58.grid_forget()      
        self.sidebar_button_11.grid(row=0, column=0, padx=8, pady=(8, 10))
        self.sidebar_button_12.grid(row=1, column=0, padx=8, pady=(8, 10))
        self.sidebar_button_13.grid(row=2, column=0, padx=8, pady=(8, 10))
        self.slider4_progressbar_2_frame.grid(row=1, rowspan=1, column=0, columnspan=6, padx=(5, 5), pady=(2, 0), sticky="sew")
        self.tabview.grid(row=1, column=9, rowspan=2, padx=(2, 5), pady=(2, 2), sticky="new")
        self.sidebar4_frame.grid_forget()     
        self.show_widget()
        self.sidebar_button_62.grid_forget()
        self.progressbar_3.set(0)
        self.progressbar_4.set(0)  
        self.progressbar_6.set(0)
        self.entry.unbind("<Return>", None)
        self.logo_info_status1.configure(text = "[0]")
        self.logo_info_status2.configure(text = "[0]")
        self.logo_info_status3.configure(text = "[0]")
        self.logo_info_status4.configure(text = "[100000]")
        self.logo_info_status11.configure(text = _("за уровень"))
        self.logo_info_status12.configure(text = _("ошибки"))
        self.logo_info_status13.configure(text = _("за игру"))
        self.logo_info_status14.configure(text = _("бодрость"))
        move_geme_progress[0] = 100000
        self.progressbar_5.set(1)
        game_selection = 0        
        self.textbox.delete("1.0", "end")
        self.textbox.insert("0.0", "\n" + _(" Смельчак!!!") + "!\n\n" + _("        Будь безпристрастен ") + "\n" + 
                                         "\n" + _("Не забывай о правилах...") + "\n"*2 + _("       ПОКАЖИ КТО ТУТ ГЛАВНЫЙ!!!"))

    # закрытие окна игры
    def game_delete(self):
        print("game_delete")
        message = _("Закрываем все вот это?")
        if mb.askyesno(message=message, parent=self):
            self.destroy()

if __name__ == "__main__":
    app = App()
    app.create_rgb_sliders()
    app.mainloop()
